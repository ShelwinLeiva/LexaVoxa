import json
import sys
from pathlib import Path

from gtts import gTTS

RAIZ = Path("src/main/resources")
CONTENIDO = RAIZ / "contenido" / "introductions"
AUDIO = RAIZ / "static" / "audio" / "introductions"
FORZAR = "--force" in sys.argv

for archivo in sorted(CONTENIDO.glob("*.json")):
    datos = json.loads(archivo.read_text(encoding="utf-8"))
    ejercicios = datos.get("ejercicios", [])
    if not ejercicios:
        continue
    prefijo = archivo.name.split("-")[0]
    carpeta = AUDIO / prefijo
    carpeta.mkdir(parents=True, exist_ok=True)
    for posicion, ejercicio in enumerate(ejercicios, start=1):
        texto = ejercicio.get("audioTexto")
        if not texto:
            continue
        destino = carpeta / f"{posicion}.mp3"
        if destino.exists() and not FORZAR:
            continue
        gTTS(text=texto, lang="en", tld="com").save(str(destino))
        print(f"OK {destino}")