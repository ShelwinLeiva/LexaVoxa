package com.lexavoxa.app.config;

import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.lexavoxa.app.modelo.Curso;
import com.lexavoxa.app.modelo.Ejercicio;
import com.lexavoxa.app.modelo.Leccion;
import com.lexavoxa.app.modelo.PaginaLeccion;
import com.lexavoxa.app.repositorio.CursoRepositorio;
import com.lexavoxa.app.repositorio.LeccionRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@Order(3)
public class LeccionSeeder implements CommandLineRunner {

    private static final String RUTA_CONTENIDO = "classpath*:contenido/introductions/*.json";

    private record Definicion(int orden, String nombre, String tipo, String descripcion) {
    }

    private record Contenido(List<PaginaLeccion> paginas, String modo, List<Ejercicio> ejercicios) {
    }

    @Autowired
    private LeccionRepositorio leccionRepositorio;

    @Autowired
    private CursoRepositorio cursoRepositorio;

    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public void run(String... args) {
        Curso curso = cursoRepositorio.findAll()
                .stream()
                .filter(c -> "Introductions".equals(c.getNombre()) && "inglés".equalsIgnoreCase(c.getIdioma()))
                .findFirst()
                .orElse(null);

        if (curso == null) {
            return;
        }

        Map<Integer, Resource> archivos = cargarArchivos();

        Map<Integer, Leccion> existentes = new HashMap<>();
        for (Leccion leccion : leccionRepositorio.findByCursoIdOrderByOrdenAsc(curso.getId())) {
            existentes.putIfAbsent(leccion.getOrden(), leccion);
        }

        for (Definicion d : definiciones()) {
            Leccion leccion = existentes.getOrDefault(d.orden(), new Leccion());
            Contenido contenido = leerContenido(archivos.get(d.orden()), d.orden());

            leccion.setCursoId(curso.getId());
            leccion.setOrden(d.orden());
            leccion.setNombre(d.nombre());
            leccion.setTipo(d.tipo());
            leccion.setDescripcion(d.descripcion());
            leccion.setXpOtorgado(xpPorTipo(d.tipo()));
            leccion.setTiempoEstimadoMinutos(minutosPorTipo(d.tipo()));
            leccion.setPaginas(contenido.paginas());
            leccion.setModo(contenido.modo());
            leccion.setEjercicios(contenido.ejercicios());
            leccionRepositorio.save(leccion);
        }
    }

    private List<Definicion> definiciones() {
        return List.of(
                new Definicion(1, "Hi, My Name Is...", "contenido", "Saludos, nombre y presentación"),
                new Definicion(2, "This Is Me", "contenido", "Vocabulario de información personal"),
                new Definicion(3, "I Am / I'm", "contenido", "Pronombres personales y verbo to be"),
                new Definicion(4, "What's Your Name?", "practica", "Preguntar y responder información personal"),
                new Definicion(5, "What Do You Like?", "contenido", "Gustos, intereses y favoritos"),
                new Definicion(6, "My Favorite Things", "practica", "Actividad: clasificar y seleccionar cosas favoritas"),
                new Definicion(7, "Listen & Meet Someone", "escucha", "Comprender una presentación"),
                new Definicion(8, "Nice to Meet You!", "practica", "Speaking: simulación de una conversación"),
                new Definicion(9, "About Me", "practica", "Writing: crear un pequeño perfil personal"),
                new Definicion(10, "Let's Review!", "repaso", "Pronombres, to be, preguntas y vocabulario"),
                new Definicion(11, "Mini Quiz", "repaso", "Quiz de 8 a 10 preguntas")
        );
    }

    private Map<Integer, Resource> cargarArchivos() {
        Map<Integer, Resource> archivos = new HashMap<>();
        try {
            for (Resource recurso : new PathMatchingResourcePatternResolver().getResources(RUTA_CONTENIDO)) {
                String nombre = recurso.getFilename();
                if (nombre == null || !nombre.matches("\\d+-.*\\.json")) {
                    continue;
                }
                archivos.put(Integer.parseInt(nombre.substring(0, nombre.indexOf('-'))), recurso);
            }
        } catch (IOException e) {
            throw new IllegalStateException("No se pudo listar el contenido de las lecciones", e);
        }
        return archivos;
    }

    private Contenido leerContenido(Resource recurso, int orden) {
        if (recurso == null) {
            return new Contenido(new ArrayList<>(), null, new ArrayList<>());
        }
        try (InputStream entrada = recurso.getInputStream()) {
            JsonNode raiz = objectMapper.readTree(entrada);

            List<PaginaLeccion> paginas = new ArrayList<>();
            JsonNode nodoPaginas = raiz.get("paginas");
            if (nodoPaginas != null && !nodoPaginas.isNull()) {
                paginas = objectMapper.convertValue(nodoPaginas, new TypeReference<List<PaginaLeccion>>() {
                });
            }

            String modo = null;
            JsonNode nodoModo = raiz.get("modo");
            if (nodoModo != null && !nodoModo.isNull()) {
                modo = objectMapper.convertValue(nodoModo, String.class);
            }

            List<Ejercicio> ejercicios = new ArrayList<>();
            JsonNode nodoEjercicios = raiz.get("ejercicios");
            if (nodoEjercicios != null && !nodoEjercicios.isNull()) {
                ejercicios = objectMapper.convertValue(nodoEjercicios, new TypeReference<List<Ejercicio>>() {
                });
            }

            for (int i = 0; i < ejercicios.size(); i++) {
                Ejercicio ejercicio = ejercicios.get(i);
                if (ejercicio.getAudioTexto() != null && !ejercicio.getAudioTexto().isBlank()) {
                    ejercicio.setAudioUrl("/audio/introductions/" + String.format("%02d", orden) + "/" + (i + 1) + ".mp3");
                }
            }

            return new Contenido(paginas, modo, ejercicios);
        } catch (IOException | RuntimeException e) {
            throw new IllegalStateException("Error leyendo el contenido " + recurso.getFilename(), e);
        }
    }

    private int xpPorTipo(String tipo) {
        return switch (tipo) {
            case "practica" -> 25;
            case "repaso" -> 30;
            default -> 15;
        };
    }

    private int minutosPorTipo(String tipo) {
        return switch (tipo) {
            case "practica" -> 5;
            case "repaso" -> 6;
            default -> 3;
        };
    }
}