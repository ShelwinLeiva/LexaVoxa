package com.lexavoxa.app.servicio;

import com.lexavoxa.app.modelo.Curso;
import com.lexavoxa.app.repositorio.CursoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

// Cambios:
// 1) listarCursosPorIdiomaYRango ahora ordena por "orden"
// 2) NUEVO obtenerCursoAnterior: mismo idioma + mismo rango + orden - 1
//    (devuelve null si es el primer curso del rango, o sea no bloquea)
@Service
public class CursoServicio {

    @Autowired
    private CursoRepositorio cursoRepositorio;

    public List<Curso> listarCursos() {
        return cursoRepositorio.findAll();
    }

    public Curso guardarCurso(Curso curso) {
        return cursoRepositorio.save(curso);
    }

    public void eliminarCurso(String id) {
        cursoRepositorio.deleteById(id);
    }

    public List<Curso> listarCursosPorIdioma(String idioma) {
        return cursoRepositorio.findAll()
                .stream()
                .filter(c -> c.getIdioma().equalsIgnoreCase(idioma))
                .toList();
    }

    public List<Curso> listarCursosPorIdiomaYRango(String idioma, String rangoId) {
        return cursoRepositorio.findAll()
                .stream()
                .filter(c -> c.getIdioma().equalsIgnoreCase(idioma))
                .filter(c -> c.getRangoId() != null && c.getRangoId().equals(rangoId))
                .sorted(Comparator.comparingInt(Curso::getOrden))
                .toList();
    }

    public Curso obtenerCursoPorId(String id) {
        if (id == null) {
            return null;
        }
        return cursoRepositorio.findById(id).orElse(null);
    }

    public Curso obtenerCursoAnterior(Curso curso) {
        if (curso == null || curso.getOrden() <= 1) {
            return null;
        }
        return cursoRepositorio.findAll()
                .stream()
                .filter(c -> c.getIdioma().equalsIgnoreCase(curso.getIdioma()))
                .filter(c -> c.getRangoId() != null && c.getRangoId().equals(curso.getRangoId()))
                .filter(c -> c.getOrden() == curso.getOrden() - 1)
                .findFirst()
                .orElse(null);
    }
}