package com.lexavoxa.app.modelo;

public class TurnoEjercicio {

    private String hablante;
    private String texto;
    private String hueco;

    public TurnoEjercicio() {
    }

    public String getHablante() {
        return hablante;
    }

    public void setHablante(String hablante) {
        this.hablante = hablante;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public String getHueco() {
        return hueco;
    }

    public void setHueco(String hueco) {
        this.hueco = hueco;
    }

    public boolean tieneHueco() {
        return hueco != null && !hueco.isBlank();
    }
}
