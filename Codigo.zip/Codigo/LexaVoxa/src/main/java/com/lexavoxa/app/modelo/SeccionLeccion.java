package com.lexavoxa.app.modelo;

import java.util.List;

public class SeccionLeccion {

    private String titulo;
    private String texto;
    private List<Palabra> frases;
    private TablaLeccion tabla;
    private List<ReglaEjemplo> reglas;

    public SeccionLeccion() {
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public List<Palabra> getFrases() {
        return frases;
    }

    public void setFrases(List<Palabra> frases) {
        this.frases = frases;
    }

    public TablaLeccion getTabla() {
        return tabla;
    }

    public void setTabla(TablaLeccion tabla) {
        this.tabla = tabla;
    }

    public List<ReglaEjemplo> getReglas() {
        return reglas;
    }

    public void setReglas(List<ReglaEjemplo> reglas) {
        this.reglas = reglas;
    }
}
