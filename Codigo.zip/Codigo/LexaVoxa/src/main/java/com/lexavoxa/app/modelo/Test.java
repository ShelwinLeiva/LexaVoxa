package com.lexavoxa.app.modelo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document(collection = "Tests")
public class Test {

    @Id
    private String id;
    private String cursoId;
    private List<String> preguntaIds;
    private List<Ejercicio> ejercicios;
    private int xpOtorgado;
    private int puntajeMinimoAprobacion;

    public Test() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCursoId() {
        return cursoId;
    }

    public void setCursoId(String cursoId) {
        this.cursoId = cursoId;
    }

    public List<String> getPreguntaIds() {
        return preguntaIds;
    }

    public void setPreguntaIds(List<String> preguntaIds) {
        this.preguntaIds = preguntaIds;
    }

    public List<Ejercicio> getEjercicios() {
        return ejercicios;
    }

    public void setEjercicios(List<Ejercicio> ejercicios) {
        this.ejercicios = ejercicios;
    }

    public int getXpOtorgado() {
        return xpOtorgado;
    }

    public void setXpOtorgado(int xpOtorgado) {
        this.xpOtorgado = xpOtorgado;
    }

    public int getPuntajeMinimoAprobacion() {
        return puntajeMinimoAprobacion;
    }

    public void setPuntajeMinimoAprobacion(int puntajeMinimoAprobacion) {
        this.puntajeMinimoAprobacion = puntajeMinimoAprobacion;
    }
}