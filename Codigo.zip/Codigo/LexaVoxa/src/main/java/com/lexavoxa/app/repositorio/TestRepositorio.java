package com.lexavoxa.app.repositorio;

import com.lexavoxa.app.modelo.Test;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface TestRepositorio extends MongoRepository<Test, String> {
    Test findByCursoId(String cursoId);
}