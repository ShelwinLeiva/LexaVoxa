package com.lexavoxa.app.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/", "/registro", "/login", "/css/**", "/js/**", "/images/**").permitAll()
                        .requestMatchers("/audio/**").authenticated()
                        .requestMatchers("/cursos/*/lecciones").authenticated()
                        .requestMatchers("/cursos/*/test").authenticated()
                        .requestMatchers("/cursos-disponibles/**").authenticated()
                        .requestMatchers("/lecciones/*/ver").authenticated()
                        .requestMatchers("/lecciones/*/ejercicios/*/responder").authenticated()
                        .requestMatchers("/lecciones/*/completar").authenticated()
                        .requestMatchers("/cursos/**", "/lecciones/**", "/rangos/**", "/palabras/**", "/preguntas/**", "/tests/**").hasRole("ADMIN")
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginPage("/login")
                        .usernameParameter("email")
                        .passwordParameter("contrasena")
                        .loginProcessingUrl("/login")
                        .defaultSuccessUrl("/post-login", true)
                        .failureUrl("/login?error")
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/login?logout")
                        .permitAll()
                )
                .csrf(csrf -> csrf.disable());

        return http.build();
    }
}