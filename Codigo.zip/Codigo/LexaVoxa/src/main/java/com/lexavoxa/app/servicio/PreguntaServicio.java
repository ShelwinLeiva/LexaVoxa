package com.lexavoxa.app.servicio;

import com.lexavoxa.app.modelo.Pregunta;
import com.lexavoxa.app.repositorio.PreguntaRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PreguntaServicio {

    @Autowired
    private PreguntaRepositorio preguntaRepositorio;

    public List<Pregunta> listarPreguntas() {
        return preguntaRepositorio.findAll();
    }

    public Pregunta guardarPregunta(Pregunta pregunta) {
        return preguntaRepositorio.save(pregunta);
    }

    public void eliminarPregunta(String id) {
        preguntaRepositorio.deleteById(id);
    }

    public Pregunta obtenerPreguntaPorId(String id) {
        return preguntaRepositorio.findById(id).orElse(null);
    }

    public List<Pregunta> obtenerPreguntasPorIds(List<String> ids) {
        return preguntaRepositorio.findAllById(ids);
    }
}