package com.lexavoxa.app.servicio;

public class ResumenEjercicios {

    private final int aciertos;
    private final int total;
    private final int bonusXp;
    private final boolean todosCerrados;

    public ResumenEjercicios(int aciertos, int total, int bonusXp, boolean todosCerrados) {
        this.aciertos = aciertos;
        this.total = total;
        this.bonusXp = bonusXp;
        this.todosCerrados = todosCerrados;
    }

    public int getAciertos() {
        return aciertos;
    }

    public int getTotal() {
        return total;
    }

    public int getBonusXp() {
        return bonusXp;
    }

    public boolean isTodosCerrados() {
        return todosCerrados;
    }
}
