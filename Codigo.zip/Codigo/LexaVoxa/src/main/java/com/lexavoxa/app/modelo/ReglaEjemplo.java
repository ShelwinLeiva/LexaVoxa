package com.lexavoxa.app.modelo;

public class ReglaEjemplo {

    private String antes;
    private String despues;

    public ReglaEjemplo() {
    }

    public String getAntes() {
        return antes;
    }

    public void setAntes(String antes) {
        this.antes = antes;
    }

    public String getDespues() {
        return despues;
    }

    public void setDespues(String despues) {
        this.despues = despues;
    }
}