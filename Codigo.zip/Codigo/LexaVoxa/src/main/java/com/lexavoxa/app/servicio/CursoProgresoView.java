package com.lexavoxa.app.servicio;

import com.lexavoxa.app.modelo.Curso;

public class CursoProgresoView {

    private Curso curso;
    private String rangoNombre;
    private int totalLecciones;
    private int leccionesCompletadas;
    private int porcentaje;
    private String estado;
    private boolean bloqueado;

    public CursoProgresoView(Curso curso, String rangoNombre, int totalLecciones, int leccionesCompletadas) {
        this.curso = curso;
        this.rangoNombre = rangoNombre;
        this.totalLecciones = totalLecciones;
        this.leccionesCompletadas = leccionesCompletadas;
        this.porcentaje = totalLecciones > 0 ? (leccionesCompletadas * 100 / totalLecciones) : 0;

        if (this.porcentaje >= 100 && totalLecciones > 0) {
            this.estado = "completado";
        } else if (this.porcentaje > 0) {
            this.estado = "progreso";
        } else {
            this.estado = "no_iniciado";
        }
    }

    public Curso getCurso() {
        return curso;
    }

    public String getRangoNombre() {
        return rangoNombre;
    }

    public int getTotalLecciones() {
        return totalLecciones;
    }

    public int getLeccionesCompletadas() {
        return leccionesCompletadas;
    }

    public int getPorcentaje() {
        return porcentaje;
    }

    public String getEstado() {
        return estado;
    }

    public boolean isBloqueado() {
        return bloqueado;
    }

    public void setBloqueado(boolean bloqueado) {
        this.bloqueado = bloqueado;
    }
}