package com.lexavoxa.app.repositorio;

import com.lexavoxa.app.modelo.Curso;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CursoRepositorio extends MongoRepository<Curso, String> {
}
