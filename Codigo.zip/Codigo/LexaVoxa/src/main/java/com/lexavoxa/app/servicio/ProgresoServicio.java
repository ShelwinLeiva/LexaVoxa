package com.lexavoxa.app.servicio;

import com.lexavoxa.app.modelo.EventoXp;
import com.lexavoxa.app.modelo.Leccion;
import com.lexavoxa.app.modelo.Progreso;
import com.lexavoxa.app.repositorio.EventoXpRepositorio;
import com.lexavoxa.app.repositorio.ProgresoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ProgresoServicio {

    private static final int XP_POR_LECCION = 50;

    @Autowired
    private ProgresoRepositorio progresoRepositorio;

    @Autowired
    private EventoXpRepositorio eventoXpRepositorio;

    @Autowired
    private UsuarioServicio usuarioServicio;

    @Autowired
    private LeccionServicio leccionServicio;

    @Autowired
    private EjercicioServicio ejercicioServicio;

    public boolean completarLeccion(String usuarioId, String leccionId) {
        Leccion leccion = leccionServicio.obtenerLeccionPorId(leccionId);
        if (leccion == null) {
            return false;
        }

        String estado = calcularEstados(usuarioId, leccion.getCursoId()).get(leccionId);
        if (!"desbloqueada".equals(estado)) {
            return false;
        }

        boolean exigeEjercicios = !"contenido".equals(leccion.getTipo());
        boolean tieneEjercicios = ejercicioServicio.tieneEjercicios(leccion);
        if (exigeEjercicios && !tieneEjercicios) {
            return false;
        }

        int bonus = 0;
        if (tieneEjercicios) {
            ResumenEjercicios resumen = ejercicioServicio.resumen(usuarioId, leccion);
            if (!resumen.isTodosCerrados()) {
                return false;
            }
            bonus = resumen.getBonusXp();
        }

        Progreso progreso = new Progreso();
        progreso.setUsuarioId(usuarioId);
        progreso.setLeccionId(leccionId);
        progreso.setFechaCompletada(LocalDate.now());
        progresoRepositorio.save(progreso);

        int base = leccion.getXpOtorgado() > 0 ? leccion.getXpOtorgado() : XP_POR_LECCION;
        int xp = base + bonus;

        try {
            usuarioServicio.sumarExperiencia(usuarioId, xp);
            usuarioServicio.actualizarRacha(usuarioId);

            String descripcion = bonus > 0
                    ? "Completaste " + leccion.getNombre() + " (+" + base + " XP, +" + bonus + " XP extra)"
                    : "Completaste " + leccion.getNombre();
            registrarEvento(usuarioId, "LECCION_COMPLETADA", descripcion, xp);
        } catch (RuntimeException e) {
            progresoRepositorio.delete(progreso);
            throw e;
        }
        return true;
    }

    public Map<String, String> calcularEstados(String usuarioId, String cursoId) {
        List<Leccion> lecciones = leccionServicio.listarLeccionesPorCurso(cursoId);
        List<String> completadasIds = listarProgresoDeUsuario(usuarioId)
                .stream()
                .map(Progreso::getLeccionId)
                .collect(Collectors.toList());

        LinkedHashMap<String, String> estados = new LinkedHashMap<>();
        boolean anteriorCompletada = true;
        for (Leccion leccion : lecciones) {
            String estado;
            if (completadasIds.contains(leccion.getId())) {
                estado = "completada";
            } else if (anteriorCompletada) {
                estado = "desbloqueada";
            } else {
                estado = "bloqueada";
            }
            estados.put(leccion.getId(), estado);
            anteriorCompletada = estado.equals("completada");
        }
        return estados;
    }

    public List<LeccionNodoView> obtenerNodosDeCurso(String usuarioId, String cursoId) {
        Map<String, String> estados = calcularEstados(usuarioId, cursoId);
        List<LeccionNodoView> nodos = new ArrayList<>();
        for (Leccion leccion : leccionServicio.listarLeccionesPorCurso(cursoId)) {
            nodos.add(new LeccionNodoView(leccion, estados.get(leccion.getId())));
        }
        return nodos;
    }

    public void registrarEvento(String usuarioId, String tipo, String descripcion, int xp) {
        EventoXp evento = new EventoXp();
        evento.setUsuarioId(usuarioId);
        evento.setTipo(tipo);
        evento.setDescripcion(descripcion);
        evento.setXpGanado(xp);
        evento.setFecha(LocalDateTime.now());
        eventoXpRepositorio.save(evento);
    }

    public List<Progreso> listarProgresoDeUsuario(String usuarioId) {
        return progresoRepositorio.findByUsuarioId(usuarioId);
    }

    public List<EventoXp> obtenerFeedReciente(String usuarioId, int limite) {
        List<EventoXp> todos = eventoXpRepositorio.findByUsuarioIdOrderByFechaDesc(usuarioId);
        return todos.size() > limite ? todos.subList(0, limite) : todos;
    }

    public int contarLeccionesCompletadasEnCurso(String usuarioId, String cursoId) {
        List<String> idsDelCurso = leccionServicio.listarLeccionesPorCurso(cursoId)
                .stream().map(Leccion::getId).collect(Collectors.toList());

        return (int) listarProgresoDeUsuario(usuarioId)
                .stream()
                .filter(p -> idsDelCurso.contains(p.getLeccionId()))
                .count();
    }

    public int contarLeccionesCompletadasEnSemana(String usuarioId) {
        LocalDate inicioSemana = LocalDate.now().with(DayOfWeek.MONDAY);
        return (int) listarProgresoDeUsuario(usuarioId)
                .stream()
                .filter(p -> p.getFechaCompletada() != null && !p.getFechaCompletada().isBefore(inicioSemana))
                .count();
    }

    public int obtenerXpGanadoEnSemana(String usuarioId) {
        LocalDate inicioSemana = LocalDate.now().with(DayOfWeek.MONDAY);
        return eventoXpRepositorio.findByUsuarioIdOrderByFechaDesc(usuarioId)
                .stream()
                .filter(e -> e.getFecha() != null && !e.getFecha().toLocalDate().isBefore(inicioSemana))
                .mapToInt(EventoXp::getXpGanado)
                .sum();
    }

    public LinkedHashMap<String, Integer> obtenerActividadUltimos7Dias(String usuarioId) {
        LocalDate lunes = LocalDate.now().with(DayOfWeek.MONDAY);
        List<EventoXp> eventos = eventoXpRepositorio.findByUsuarioIdOrderByFechaDesc(usuarioId);
        String[] etiquetas = {"Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"};

        LinkedHashMap<String, Integer> dias = new LinkedHashMap<>();
        for (int i = 0; i < 7; i++) {
            LocalDate dia = lunes.plusDays(i);
            int xpDelDia = eventos.stream()
                    .filter(e -> e.getFecha() != null && e.getFecha().toLocalDate().isEqual(dia))
                    .mapToInt(EventoXp::getXpGanado)
                    .sum();
            dias.put(etiquetas[i], xpDelDia);
        }
        return dias;
    }
}