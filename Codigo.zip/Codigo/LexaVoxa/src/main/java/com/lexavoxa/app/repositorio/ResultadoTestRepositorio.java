package com.lexavoxa.app.repositorio;

import com.lexavoxa.app.modelo.ResultadoTest;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface ResultadoTestRepositorio extends MongoRepository<ResultadoTest, String> {
    List<ResultadoTest> findByUsuarioId(String usuarioId);
    ResultadoTest findByUsuarioIdAndCursoId(String usuarioId, String cursoId);
}