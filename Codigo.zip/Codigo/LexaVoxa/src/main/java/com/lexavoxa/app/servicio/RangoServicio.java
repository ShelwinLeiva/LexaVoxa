package com.lexavoxa.app.servicio;

import com.lexavoxa.app.modelo.Rango;
import com.lexavoxa.app.repositorio.RangoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

@Service
public class RangoServicio {

    @Autowired
    private RangoRepositorio rangoRepositorio;

    public List<Rango> listarRangos() {
        return rangoRepositorio.findAll();
    }

    public Rango guardarRango(Rango rango) {
        return rangoRepositorio.save(rango);
    }

    public void eliminarRango(String id) {
        rangoRepositorio.deleteById(id);
    }

    public Rango obtenerRangoMasBajo() {
        return rangoRepositorio.findAll()
                .stream()
                .min(Comparator.comparingInt(Rango::getPuntosRequeridos))
                .orElse(null);
    }

    public Rango obtenerRangoPorId(String id) {
        if (id == null) {
            return null;
        }
        return rangoRepositorio.findById(id).orElse(null);
    }

    public Rango obtenerSiguienteRango(Rango actual) {
        if (actual == null) {
            return null;
        }
        return rangoRepositorio.findAll()
                .stream()
                .filter(r -> r.getPuntosRequeridos() > actual.getPuntosRequeridos())
                .min(Comparator.comparingInt(Rango::getPuntosRequeridos))
                .orElse(null);
    }
}