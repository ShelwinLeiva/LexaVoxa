package com.lexavoxa.app.config;

import com.lexavoxa.app.modelo.Rango;
import com.lexavoxa.app.repositorio.RangoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class RangoSeeder implements CommandLineRunner {

    @Autowired
    private RangoRepositorio rangoRepositorio;

    @Override
    public void run(String... args) {
        if (rangoRepositorio.count() > 0) {
            return;
        }

        guardar("Bronce", 0);
        guardar("Plata", 1500);
        guardar("Oro", 3000);
        guardar("Platino", 4500);
        guardar("Diamante", 6000);
        guardar("Legendario", 8000);
    }

    private void guardar(String nombre, int puntosRequeridos) {
        Rango rango = new Rango();
        rango.setNombre(nombre);
        rango.setPuntosRequeridos(puntosRequeridos);
        rangoRepositorio.save(rango);
    }
}