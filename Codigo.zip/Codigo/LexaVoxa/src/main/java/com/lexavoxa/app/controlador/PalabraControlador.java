package com.lexavoxa.app.controlador;

import com.lexavoxa.app.modelo.Palabra;
import com.lexavoxa.app.servicio.PalabraServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class PalabraControlador {

    @Autowired
    private PalabraServicio palabraServicio;

    @GetMapping("/palabras")
    public String listarPalabras(Model model) {
        model.addAttribute("palabras", palabraServicio.listarPalabras());
        return "palabras";
    }

    @PostMapping("/palabras/crear")
    public String crearPalabra(@RequestParam String textoOriginal,
                               @RequestParam String traduccion,
                               @RequestParam String idioma) {
        Palabra palabra = new Palabra();
        palabra.setTextoOriginal(textoOriginal);
        palabra.setTraduccion(traduccion);
        palabra.setIdioma(idioma);
        palabraServicio.guardarPalabra(palabra);
        return "redirect:/palabras";
    }

    @GetMapping("/palabras/eliminar/{id}")
    public String eliminarPalabra(@PathVariable String id) {
        palabraServicio.eliminarPalabra(id);
        return "redirect:/palabras";
    }
}
