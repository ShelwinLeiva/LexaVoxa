package com.lexavoxa.app.repositorio;

import com.lexavoxa.app.modelo.Progreso;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface ProgresoRepositorio extends MongoRepository<Progreso, String> {
    List<Progreso> findByUsuarioId(String usuarioId);
    Progreso findByUsuarioIdAndLeccionId(String usuarioId, String leccionId);
}