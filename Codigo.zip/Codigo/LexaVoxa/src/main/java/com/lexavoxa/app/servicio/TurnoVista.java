package com.lexavoxa.app.servicio;

public class TurnoVista {

    private final String hablante;
    private final String texto;
    private final boolean hueco;
    private final Integer indiceHueco;

    public TurnoVista(String hablante, String texto, boolean hueco, Integer indiceHueco) {
        this.hablante = hablante;
        this.texto = texto;
        this.hueco = hueco;
        this.indiceHueco = indiceHueco;
    }

    public String getHablante() {
        return hablante;
    }

    public String getTexto() {
        return texto;
    }

    public boolean isHueco() {
        return hueco;
    }

    public Integer getIndiceHueco() {
        return indiceHueco;
    }
}