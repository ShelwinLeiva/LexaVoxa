package com.lexavoxa.app.repositorio;

import com.lexavoxa.app.modelo.IntentoEjercicio;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface IntentoEjercicioRepositorio extends MongoRepository<IntentoEjercicio, String> {

    List<IntentoEjercicio> findByUsuarioIdAndLeccionId(String usuarioId, String leccionId);

    IntentoEjercicio findByUsuarioIdAndLeccionIdAndIndice(String usuarioId, String leccionId, int indice);
}