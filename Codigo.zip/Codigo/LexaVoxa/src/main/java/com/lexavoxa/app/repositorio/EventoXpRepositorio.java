package com.lexavoxa.app.repositorio;

import com.lexavoxa.app.modelo.EventoXp;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface EventoXpRepositorio extends MongoRepository<EventoXp, String> {
    List<EventoXp> findByUsuarioIdOrderByFechaDesc(String usuarioId);
}