package com.lexavoxa.app.repositorio;

import com.lexavoxa.app.modelo.Pregunta;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PreguntaRepositorio extends MongoRepository<Pregunta, String> {
}