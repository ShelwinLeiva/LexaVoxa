package com.lexavoxa.app.servicio;

public class RevisionPregunta {

    private final String enunciado;
    private final String tipo;
    private final boolean correcta;
    private final String respuestaUsuario;
    private final String respuestaCorrecta;
    private final String explicacion;

    public RevisionPregunta(String enunciado, String tipo, boolean correcta,
                            String respuestaUsuario, String respuestaCorrecta, String explicacion) {
        this.enunciado = enunciado;
        this.tipo = tipo;
        this.correcta = correcta;
        this.respuestaUsuario = respuestaUsuario;
        this.respuestaCorrecta = respuestaCorrecta;
        this.explicacion = explicacion;
    }

    public String getEnunciado() {
        return enunciado;
    }

    public String getTipo() {
        return tipo;
    }

    public boolean isCorrecta() {
        return correcta;
    }

    public String getRespuestaUsuario() {
        return respuestaUsuario;
    }

    public String getRespuestaCorrecta() {
        return respuestaCorrecta;
    }

    public String getExplicacion() {
        return explicacion;
    }
}