package com.lexavoxa.app.repositorio;

import com.lexavoxa.app.modelo.Rango;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface RangoRepositorio extends MongoRepository<Rango, String> {
}
