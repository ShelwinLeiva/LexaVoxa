package com.lexavoxa.app.servicio;

import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;
import com.lexavoxa.app.modelo.Curso;
import com.lexavoxa.app.modelo.Ejercicio;
import com.lexavoxa.app.modelo.ResultadoTest;
import com.lexavoxa.app.modelo.Test;
import com.lexavoxa.app.repositorio.ResultadoTestRepositorio;
import com.lexavoxa.app.repositorio.TestRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class TestServicio {

    @Autowired
    private TestRepositorio testRepositorio;

    @Autowired
    private ResultadoTestRepositorio resultadoTestRepositorio;

    @Autowired
    private CursoServicio cursoServicio;

    @Autowired
    private LeccionServicio leccionServicio;

    @Autowired
    private ProgresoServicio progresoServicio;

    @Autowired
    private UsuarioServicio usuarioServicio;

    @Autowired
    private EjercicioServicio ejercicioServicio;

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private ObjectMapper objectMapper;

    public Test guardarTest(Test test) {
        return testRepositorio.save(test);
    }

    public Test obtenerTestPorCurso(String cursoId) {
        return testRepositorio.findByCursoId(cursoId);
    }

    public ResultadoTest obtenerResultado(String usuarioId, String cursoId) {
        return resultadoTestRepositorio.findByUsuarioIdAndCursoId(usuarioId, cursoId);
    }

    public boolean cursoAprobado(String usuarioId, String cursoId) {
        ResultadoTest resultado = obtenerResultado(usuarioId, cursoId);
        return resultado != null && resultado.isAprobado();
    }

    public boolean cursoBloqueado(String usuarioId, Curso curso) {
        if (curso == null) {
            return true;
        }
        Curso anterior = cursoServicio.obtenerCursoAnterior(curso);
        return anterior != null && !cursoAprobado(usuarioId, anterior.getId());
    }

    public boolean puedeRendirTest(String usuarioId, Curso curso) {
        if (cursoBloqueado(usuarioId, curso)) {
            return false;
        }
        int total = leccionServicio.listarLeccionesPorCurso(curso.getId()).size();
        return total > 0 && progresoServicio.contarLeccionesCompletadasEnCurso(usuarioId, curso.getId()) == total;
    }

    public Test copiaPublica(Test test) {
        Test copia = new Test();
        copia.setId(test.getId());
        copia.setCursoId(test.getCursoId());
        copia.setXpOtorgado(test.getXpOtorgado());
        copia.setPuntajeMinimoAprobacion(test.getPuntajeMinimoAprobacion());
        return copia;
    }

    public List<EjercicioVista> construirEjerciciosExamen(Test test) {
        List<EjercicioVista> vistas = new ArrayList<>();
        List<Ejercicio> ejercicios = test.getEjercicios();
        if (ejercicios == null) {
            return vistas;
        }
        for (int i = 0; i < ejercicios.size(); i++) {
            vistas.add(ejercicioServicio.construirVistaExamen(ejercicios.get(i), i));
        }
        return vistas;
    }

    public CorreccionTest corregirExamen(String usuarioId, Curso curso, String respuestasJson) {
        Test test = testRepositorio.findByCursoId(curso.getId());
        if (test == null || test.getEjercicios() == null || test.getEjercicios().isEmpty()) {
            return null;
        }
        if (!puedeRendirTest(usuarioId, curso)) {
            return null;
        }

        List<Ejercicio> ejercicios = test.getEjercicios();
        int total = ejercicios.size();
        List<Object> respuestas = leerRespuestas(respuestasJson, total);

        List<RevisionPregunta> revision = new ArrayList<>();
        int aciertos = 0;
        for (int i = 0; i < total; i++) {
            Ejercicio ejercicio = ejercicios.get(i);
            Object respuesta = respuestas.get(i);
            boolean correcta = ejercicioServicio.evaluarExamen(ejercicio, respuesta);
            if (correcta) {
                aciertos++;
            }
            revision.add(new RevisionPregunta(
                    ejercicio.getEnunciado(),
                    ejercicio.getTipo(),
                    correcta,
                    ejercicioServicio.textoDeRespuestaUsuario(respuesta),
                    ejercicioServicio.textoDeRespuestaCorrecta(ejercicio),
                    ejercicio.getExplicacion()));
        }

        int puntaje = aciertos * 100 / total;
        boolean aprobadoAhora = puntaje >= test.getPuntajeMinimoAprobacion();
        LocalDateTime ahora = LocalDateTime.now();

        ResultadoTest existente = obtenerResultado(usuarioId, curso.getId());
        boolean yaAprobado = existente != null && existente.isAprobado();

        if (yaAprobado) {
            ResultadoTest intentoSinGuardar = new ResultadoTest();
            intentoSinGuardar.setUsuarioId(usuarioId);
            intentoSinGuardar.setCursoId(curso.getId());
            intentoSinGuardar.setTestId(test.getId());
            intentoSinGuardar.setPuntaje(puntaje);
            intentoSinGuardar.setAprobado(aprobadoAhora);
            intentoSinGuardar.setFecha(ahora);
            return new CorreccionTest(intentoSinGuardar, aciertos, total, revision, true);
        }

        String resultadoId = existente != null
                ? existente.getId()
                : crearResultadoPendiente(usuarioId, curso.getId(), test.getId(), ahora).getId();

        Query pendiente = Query.query(Criteria.where("id").is(resultadoId).and("aprobado").is(false));
        boolean primeraAprobacion = false;

        if (aprobadoAhora) {
            ResultadoTest previo = mongoTemplate.findAndModify(pendiente,
                    new Update().set("aprobado", true)
                            .set("puntaje", puntaje)
                            .set("fecha", ahora)
                            .set("testId", test.getId()),
                    FindAndModifyOptions.options().returnNew(false),
                    ResultadoTest.class);
            primeraAprobacion = previo != null;
        } else {
            mongoTemplate.updateFirst(pendiente,
                    new Update().set("puntaje", puntaje)
                            .set("fecha", ahora)
                            .set("testId", test.getId()),
                    ResultadoTest.class);
        }

        if (primeraAprobacion && test.getXpOtorgado() > 0) {
            try {
                usuarioServicio.sumarExperiencia(usuarioId, test.getXpOtorgado());
                usuarioServicio.actualizarRacha(usuarioId);
                progresoServicio.registrarEvento(usuarioId, "TEST_APROBADO",
                        "Aprobaste el test final de " + curso.getNombre(), test.getXpOtorgado());
            } catch (RuntimeException e) {
                mongoTemplate.updateFirst(Query.query(Criteria.where("id").is(resultadoId)),
                        new Update().set("aprobado", false),
                        ResultadoTest.class);
                throw e;
            }
        }

        ResultadoTest resultado = resultadoTestRepositorio.findById(resultadoId).orElse(existente);
        return new CorreccionTest(resultado, aciertos, total, revision, false);
    }

    private ResultadoTest crearResultadoPendiente(String usuarioId, String cursoId, String testId, LocalDateTime fecha) {
        ResultadoTest nuevo = new ResultadoTest();
        nuevo.setUsuarioId(usuarioId);
        nuevo.setCursoId(cursoId);
        nuevo.setTestId(testId);
        nuevo.setPuntaje(0);
        nuevo.setAprobado(false);
        nuevo.setFecha(fecha);
        return resultadoTestRepositorio.save(nuevo);
    }

    private List<Object> leerRespuestas(String json, int total) {
        if (json == null || json.isBlank()) {
            throw new IllegalArgumentException("Faltan las respuestas");
        }

        List<Object> lista;
        try {
            lista = objectMapper.readValue(json, new TypeReference<List<Object>>() {
            });
        } catch (RuntimeException e) {
            throw new IllegalArgumentException("Formato de respuestas inválido");
        }

        if (lista == null || lista.size() > total) {
            throw new IllegalArgumentException("La cantidad de respuestas no coincide con las preguntas");
        }

        List<Object> completa = new ArrayList<>(lista);
        while (completa.size() < total) {
            completa.add("");
        }
        return completa;
    }
}