package com.lexavoxa.app.servicio;

import com.lexavoxa.app.modelo.Palabra;
import com.lexavoxa.app.repositorio.PalabraRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PalabraServicio {

    @Autowired
    private PalabraRepositorio palabraRepositorio;

    public List<Palabra> listarPalabras() {
        return palabraRepositorio.findAll();
    }

    public Palabra guardarPalabra(Palabra palabra) {
        return palabraRepositorio.save(palabra);
    }

    public void eliminarPalabra(String id) {
        palabraRepositorio.deleteById(id);
    }
}