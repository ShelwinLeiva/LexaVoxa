package com.lexavoxa.app.controlador;

import com.lexavoxa.app.modelo.Curso;
import com.lexavoxa.app.modelo.Test;
import com.lexavoxa.app.modelo.Usuario;
import com.lexavoxa.app.servicio.CorreccionTest;
import com.lexavoxa.app.servicio.CursoServicio;
import com.lexavoxa.app.servicio.TestServicio;
import com.lexavoxa.app.servicio.UsuarioServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TestControlador {

    @Autowired
    private TestServicio testServicio;

    @Autowired
    private CursoServicio cursoServicio;

    @Autowired
    private UsuarioServicio usuarioServicio;

    @GetMapping("/cursos/{id}/test")
    public String verTest(@PathVariable String id, Authentication authentication, Model model) {
        Usuario usuario = usuarioServicio.obtenerUsuarioPorEmail(authentication.getName());
        Curso curso = cursoServicio.obtenerCursoPorId(id);

        String redireccion = redireccionSiNoPuede(usuario, curso, id);
        if (redireccion != null) {
            return redireccion;
        }

        Test test = testServicio.obtenerTestPorCurso(id);
        if (test == null || test.getEjercicios() == null || test.getEjercicios().isEmpty()) {
            return "redirect:/cursos/" + id + "/lecciones";
        }

        model.addAttribute("curso", curso);
        model.addAttribute("test", testServicio.copiaPublica(test));
        model.addAttribute("ejercicios", testServicio.construirEjerciciosExamen(test));
        model.addAttribute("yaAprobado", testServicio.cursoAprobado(usuario.getId(), id));
        return "test";
    }

    @PostMapping("/cursos/{id}/test")
    public String corregirTest(@PathVariable String id,
                               @RequestParam(required = false) String respuestas,
                               Authentication authentication,
                               Model model) {
        Usuario usuario = usuarioServicio.obtenerUsuarioPorEmail(authentication.getName());
        Curso curso = cursoServicio.obtenerCursoPorId(id);

        String redireccion = redireccionSiNoPuede(usuario, curso, id);
        if (redireccion != null) {
            return redireccion;
        }

        CorreccionTest correccion;
        try {
            correccion = testServicio.corregirExamen(usuario.getId(), curso, respuestas);
        } catch (IllegalArgumentException e) {
            return "redirect:/cursos/" + id + "/test";
        }

        if (correccion == null) {
            return "redirect:/cursos/" + id + "/lecciones";
        }

        model.addAttribute("curso", curso);
        model.addAttribute("resultado", correccion.getResultado());
        model.addAttribute("aciertos", correccion.getAciertos());
        model.addAttribute("total", correccion.getTotal());
        model.addAttribute("revision", correccion.getRevision());
        model.addAttribute("yaAprobado", correccion.isYaAprobado());
        return "resultado-test";
    }

    private String redireccionSiNoPuede(Usuario usuario, Curso curso, String id) {
        if (curso == null || testServicio.cursoBloqueado(usuario.getId(), curso)) {
            return "redirect:/cursos-disponibles";
        }
        if (!testServicio.puedeRendirTest(usuario.getId(), curso)) {
            return "redirect:/cursos/" + id + "/lecciones";
        }
        return null;
    }
}