package com.lexavoxa.app.config;

import com.lexavoxa.app.modelo.Pregunta;
import com.lexavoxa.app.repositorio.PreguntaRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@Order(4)
public class PreguntaSeeder implements CommandLineRunner {

    public static final List<String> ENUNCIADOS_INTRODUCTIONS = List.of(
            "¿Qué saludo se usa solo para despedirse antes de dormir?",
            "¿Cómo se dice «Me llamo Ana» de forma natural en inglés?",
            "Completa: She ___ a teacher.",
            "¿Cuál es la forma corta de «They are friends»?",
            "¿Cómo se dice «Tengo 20 años» en inglés?",
            "¿Cuál es la respuesta corta correcta a «Are you a student?» (sí lo eres)?",
            "¿Cómo se pregunta «¿De dónde eres?» en inglés?",
            "Completa: I ___ like fish.",
            "Completa: He ___ football.",
            "¿Cuál oración es correcta para preguntar el color favorito?"
    );

    @Autowired
    private PreguntaRepositorio preguntaRepositorio;

    @Override
    public void run(String... args) {
        Map<String, Pregunta> existentes = preguntaRepositorio.findAll()
                .stream()
                .filter(p -> p.getEnunciado() != null)
                .collect(Collectors.toMap(Pregunta::getEnunciado, p -> p, (a, b) -> a));

        guardar(existentes, 0, "Good night",
                List.of("Good morning", "Good afternoon", "Good night", "Hello"));

        guardar(existentes, 1, "My name's Ana.",
                List.of("I call me Ana.", "My name's Ana.", "I name Ana.", "Me name Ana."));

        guardar(existentes, 2, "is",
                List.of("am", "are", "be", "is"));

        guardar(existentes, 3, "They're friends.",
                List.of("Theyre friends.", "They's friends.", "They're friends.", "Them're friends."));

        guardar(existentes, 4, "I'm 20 years old.",
                List.of("I have 20 years.", "I am have 20.", "I has 20 years old.", "I'm 20 years old."));

        guardar(existentes, 5, "Yes, I am.",
                List.of("Yes, I'm.", "Yes, I am.", "Yes, I do.", "Yes, am I."));

        guardar(existentes, 6, "Where are you from?",
                List.of("What are you from?", "Where do you from?", "Where are you from?", "Who are you from?"));

        guardar(existentes, 7, "don't",
                List.of("don't", "doesn't", "no", "not"));

        guardar(existentes, 8, "likes",
                List.of("like", "liking", "does like", "likes"));

        guardar(existentes, 9, "What's your favorite color?",
                List.of("What your favorite color is?", "What's your favorite color?",
                        "Which is favorite your color?", "What's favorite your color?"));
    }

    private void guardar(Map<String, Pregunta> existentes, int indice,
                         String respuestaCorrecta, List<String> opciones) {
        String enunciado = ENUNCIADOS_INTRODUCTIONS.get(indice);
        Pregunta pregunta = existentes.getOrDefault(enunciado, new Pregunta());
        pregunta.setEnunciado(enunciado);
        pregunta.setRespuestaCorrecta(respuestaCorrecta);
        pregunta.setOpciones(opciones);
        preguntaRepositorio.save(pregunta);
    }
}