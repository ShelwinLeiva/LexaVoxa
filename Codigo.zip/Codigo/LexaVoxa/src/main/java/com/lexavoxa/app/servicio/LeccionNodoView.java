package com.lexavoxa.app.servicio;

import com.lexavoxa.app.modelo.Leccion;

public class LeccionNodoView {

    private Leccion leccion;
    private String estado;

    public LeccionNodoView(Leccion leccion, String estado) {
        this.leccion = leccion;
        this.estado = estado;
    }

    public Leccion getLeccion() {
        return leccion;
    }

    public String getEstado() {
        return estado;
    }
}