package com.lexavoxa.app.servicio;

import java.util.ArrayList;
import java.util.List;

public class EjercicioVista {

    private int indice;
    private String tipo;
    private String enunciado;
    private List<String> opciones;
    private String audioUrl;
    private String estado;
    private int intentosUsados;
    private String ultimaPista;
    private String respuestaCorrecta;
    private List<String> bloques = new ArrayList<>();
    private List<TurnoVista> turnos = new ArrayList<>();
    private List<String> solucion = new ArrayList<>();

    public EjercicioVista() {
    }

    public int getIndice() {
        return indice;
    }

    public void setIndice(int indice) {
        this.indice = indice;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getEnunciado() {
        return enunciado;
    }

    public void setEnunciado(String enunciado) {
        this.enunciado = enunciado;
    }

    public List<String> getOpciones() {
        return opciones;
    }

    public void setOpciones(List<String> opciones) {
        this.opciones = opciones;
    }

    public String getAudioUrl() {
        return audioUrl;
    }

    public void setAudioUrl(String audioUrl) {
        this.audioUrl = audioUrl;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getIntentosUsados() {
        return intentosUsados;
    }

    public void setIntentosUsados(int intentosUsados) {
        this.intentosUsados = intentosUsados;
    }

    public String getUltimaPista() {
        return ultimaPista;
    }

    public void setUltimaPista(String ultimaPista) {
        this.ultimaPista = ultimaPista;
    }

    public String getRespuestaCorrecta() {
        return respuestaCorrecta;
    }

    public void setRespuestaCorrecta(String respuestaCorrecta) {
        this.respuestaCorrecta = respuestaCorrecta;
    }

    public List<String> getBloques() {
        return bloques;
    }

    public void setBloques(List<String> bloques) {
        this.bloques = bloques != null ? bloques : new ArrayList<>();
    }

    public List<TurnoVista> getTurnos() {
        return turnos;
    }

    public void setTurnos(List<TurnoVista> turnos) {
        this.turnos = turnos != null ? turnos : new ArrayList<>();
    }

    public List<String> getSolucion() {
        return solucion;
    }

    public void setSolucion(List<String> solucion) {
        this.solucion = solucion != null ? solucion : new ArrayList<>();
    }
}