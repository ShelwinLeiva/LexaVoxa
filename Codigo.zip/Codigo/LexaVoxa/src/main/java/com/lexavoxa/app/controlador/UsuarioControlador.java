package com.lexavoxa.app.controlador;

import com.lexavoxa.app.modelo.Usuario;
import com.lexavoxa.app.servicio.UsuarioServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class UsuarioControlador {

    @Autowired
    private UsuarioServicio usuarioServicio;

    @GetMapping("/registro")
    public String mostrarFormularioRegistro() {
        return "registro";
    }

    @PostMapping("/registro")
    public String registrarUsuario(@RequestParam String nombre,
                                   @RequestParam String nombreUsuario,
                                   @RequestParam int edad,
                                   @RequestParam String email,
                                   @RequestParam String contrasena,
                                   Model model) {
        try {
            Usuario usuario = new Usuario();
            usuario.setNombre(nombre);
            usuario.setNombreUsuario(nombreUsuario);
            usuario.setEdad(edad);
            usuario.setEmail(email);
            usuario.setContrasena(contrasena);
            usuarioServicio.registrarUsuario(usuario);
            return "redirect:/login?registrado";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "registro";
        }
    }

    @GetMapping("/login")
    public String mostrarFormularioLogin(@RequestParam(required = false) String error, Model model) {
        if (error != null) {
            model.addAttribute("error", "Email o contraseña incorrectos");
        }
        return "login";
    }

    @GetMapping("/post-login")
    public String despuesDeLogin(Authentication authentication) {
        Usuario usuario = usuarioServicio.obtenerUsuarioPorEmail(authentication.getName());

        if (usuario.getIdiomas() == null || usuario.getIdiomas().isEmpty()) {
            return "redirect:/seleccionar-idioma";
        }
        if (usuario.getMetaDiaria() == 0) {
            return "redirect:/meta-diaria";
        }
        return "redirect:/mis-cursos";
    }

    @GetMapping("/seleccionar-idioma")
    public String mostrarSeleccionIdioma() {
        return "seleccionar-idioma";
    }

    @PostMapping("/seleccionar-idioma")
    public String guardarIdioma(@RequestParam String idioma, Authentication authentication) {
        Usuario usuario = usuarioServicio.obtenerUsuarioPorEmail(authentication.getName());
        usuarioServicio.seleccionarIdioma(usuario.getId(), idioma);
        return "redirect:/meta-diaria";
    }

    @GetMapping("/meta-diaria")
    public String mostrarMetaDiaria() {
        return "meta-diaria";
    }

    @PostMapping("/meta-diaria")
    public String guardarMetaDiaria(@RequestParam int minutos, Authentication authentication) {
        Usuario usuario = usuarioServicio.obtenerUsuarioPorEmail(authentication.getName());
        usuarioServicio.definirMetaDiaria(usuario.getId(), minutos);
        return "redirect:/mis-cursos";
    }

    @GetMapping("/cuenta")
    public String verCuenta(Authentication authentication, Model model) {
        Usuario usuario = usuarioServicio.obtenerUsuarioPorEmail(authentication.getName());
        model.addAttribute("usuario", usuario);
        return "cuenta";
    }
}
