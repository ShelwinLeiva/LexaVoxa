package com.lexavoxa.app.servicio;

import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.ObjectMapper;
import com.lexavoxa.app.modelo.Ejercicio;
import com.lexavoxa.app.modelo.IntentoEjercicio;
import com.lexavoxa.app.modelo.Leccion;
import com.lexavoxa.app.modelo.TurnoEjercicio;
import com.lexavoxa.app.repositorio.IntentoEjercicioRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Service
public class EjercicioServicio {

    public static final int MAX_INTENTOS = 3;

    @Value("${lexavoxa.xp.bonus.intento1:5}")
    private int bonusIntento1;

    @Value("${lexavoxa.xp.bonus.intento2:3}")
    private int bonusIntento2;

    @Value("${lexavoxa.xp.bonus.intento3:2}")
    private int bonusIntento3;

    @Autowired
    private IntentoEjercicioRepositorio intentoRepositorio;

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private ObjectMapper objectMapper;

    public boolean tieneEjercicios(Leccion leccion) {
        return leccion.getEjercicios() != null && !leccion.getEjercicios().isEmpty();
    }

    public String modoDe(Leccion leccion) {
        return "compasivo".equals(leccion.getModo()) ? "compasivo" : "estricto";
    }

    public List<EjercicioVista> construirVistas(String usuarioId, Leccion leccion) {
        List<EjercicioVista> vistas = new ArrayList<>();
        if (!tieneEjercicios(leccion)) {
            return vistas;
        }

        Map<Integer, IntentoEjercicio> mapa = mapaDeIntentos(usuarioId, leccion.getId());
        boolean compasivo = "compasivo".equals(modoDe(leccion));
        List<Ejercicio> ejercicios = leccion.getEjercicios();

        for (int i = 0; i < ejercicios.size(); i++) {
            Ejercicio ejercicio = ejercicios.get(i);
            IntentoEjercicio intento = mapa.get(i);
            String estado = intento != null ? intento.getEstado() : "pendiente";
            int usados = intento != null ? intento.getIntentos() : 0;

            EjercicioVista vista = new EjercicioVista();
            vista.setIndice(i);
            vista.setTipo(ejercicio.getTipo());
            vista.setEnunciado(ejercicio.getEnunciado());
            vista.setOpciones(ejercicio.getOpciones() != null ? new ArrayList<>(ejercicio.getOpciones()) : null);
            vista.setAudioUrl(ejercicio.getAudioUrl());
            vista.setEstado(estado);
            vista.setIntentosUsados(usados);

            if ("pendiente".equals(estado) && usados > 0 && compasivo) {
                vista.setUltimaPista(pistaPara(ejercicio, usados));
            }

            if (esConversacion(ejercicio)) {
                List<String> huecos = textosDeHuecos(ejercicio);
                vista.setTurnos(construirTurnos(ejercicio));
                vista.setBloques(construirBloques(ejercicio, huecos));
                if (!"pendiente".equals(estado)) {
                    vista.setSolucion(huecos);
                }
            } else if ("revelado".equals(estado)) {
                vista.setRespuestaCorrecta(primeraRespuesta(ejercicio));
            }
            vistas.add(vista);
        }
        return vistas;
    }

    public EjercicioVista construirVistaExamen(Ejercicio ejercicio, int indice) {
        EjercicioVista vista = new EjercicioVista();
        vista.setIndice(indice);
        vista.setTipo(ejercicio.getTipo());
        vista.setEnunciado(ejercicio.getEnunciado());
        vista.setAudioUrl(ejercicio.getAudioUrl());
        vista.setEstado("pendiente");
        vista.setIntentosUsados(0);

        if (ejercicio.getOpciones() != null) {
            List<String> opciones = new ArrayList<>(ejercicio.getOpciones());
            Collections.shuffle(opciones);
            vista.setOpciones(opciones);
        }

        if (esConversacion(ejercicio)) {
            vista.setTurnos(construirTurnos(ejercicio));
            vista.setBloques(construirBloques(ejercicio, textosDeHuecos(ejercicio)));
        }
        return vista;
    }

    public boolean evaluarExamen(Ejercicio ejercicio, Object respuesta) {
        if (esConversacion(ejercicio)) {
            List<String> huecos = textosDeHuecos(ejercicio);
            if (huecos.isEmpty() || !(respuesta instanceof List<?> lista) || lista.size() != huecos.size()) {
                return false;
            }
            for (int i = 0; i < huecos.size(); i++) {
                String texto = lista.get(i) instanceof String s ? s : "";
                if (!normalizar(texto).equals(normalizar(huecos.get(i)))) {
                    return false;
                }
            }
            return true;
        }
        return respuesta instanceof String texto && coincide(ejercicio, texto);
    }

    public String textoDeRespuestaUsuario(Object respuesta) {
        if (respuesta instanceof List<?> lista) {
            List<String> partes = new ArrayList<>();
            for (Object elemento : lista) {
                partes.add(elemento instanceof String s ? s : "");
            }
            return String.join(" / ", partes);
        }
        return respuesta instanceof String s ? s : "";
    }

    public String textoDeRespuestaCorrecta(Ejercicio ejercicio) {
        if (esConversacion(ejercicio)) {
            return String.join(" / ", textosDeHuecos(ejercicio));
        }
        return primeraRespuesta(ejercicio);
    }

    public ResumenEjercicios resumen(String usuarioId, Leccion leccion) {
        if (!tieneEjercicios(leccion)) {
            return new ResumenEjercicios(0, 0, 0, false);
        }

        Map<Integer, IntentoEjercicio> mapa = mapaDeIntentos(usuarioId, leccion.getId());
        int total = leccion.getEjercicios().size();
        int aciertos = 0;
        int bonus = 0;
        boolean cerrados = true;

        for (int i = 0; i < total; i++) {
            IntentoEjercicio intento = mapa.get(i);
            String estado = intento != null ? intento.getEstado() : "pendiente";
            if ("acertado".equals(estado)) {
                aciertos++;
                bonus += bonusPorIntento(intento.getIntentoAcierto());
            } else if (!"revelado".equals(estado)) {
                cerrados = false;
            }
        }
        return new ResumenEjercicios(aciertos, total, bonus, cerrados);
    }

    public Map<String, Object> responder(String usuarioId, Leccion leccion, int indice,
                                         String respuesta, boolean soloLectura) {
        Ejercicio ejercicio = leccion.getEjercicios().get(indice);
        boolean conversacion = esConversacion(ejercicio);
        List<String> huecos = conversacion ? textosDeHuecos(ejercicio) : new ArrayList<>();
        List<String> respuestasUsuario = conversacion
                ? leerRespuestasConversacion(respuesta, huecos.size())
                : new ArrayList<>();

        IntentoEjercicio actual = obtenerOCrear(usuarioId, leccion.getId(), indice);

        boolean intentoRealizado = false;
        boolean correctoEnEsteIntento = false;
        int correctosEnIntento = 0;
        List<Integer> incorrectosEnIntento = new ArrayList<>();

        if (!soloLectura && "pendiente".equals(actual.getEstado())) {
            Query consulta = Query.query(Criteria.where("id").is(actual.getId())
                    .and("estado").is("pendiente")
                    .and("intentos").lt(MAX_INTENTOS));
            IntentoEjercicio tras = mongoTemplate.findAndModify(consulta,
                    new Update().inc("intentos", 1),
                    FindAndModifyOptions.options().returnNew(true),
                    IntentoEjercicio.class);

            if (tras != null) {
                intentoRealizado = true;
                int numero = tras.getIntentos();

                if (conversacion) {
                    for (int i = 0; i < huecos.size(); i++) {
                        if (normalizar(respuestasUsuario.get(i)).equals(normalizar(huecos.get(i)))) {
                            correctosEnIntento++;
                        } else {
                            incorrectosEnIntento.add(i);
                        }
                    }
                    correctoEnEsteIntento = incorrectosEnIntento.isEmpty();
                } else {
                    correctoEnEsteIntento = coincide(ejercicio, respuesta);
                }

                if (correctoEnEsteIntento) {
                    cerrar(actual.getId(), "acertado", numero);
                } else if (numero >= MAX_INTENTOS) {
                    cerrar(actual.getId(), "revelado", 0);
                }
            }
        }

        IntentoEjercicio finalIntento = intentoRepositorio.findById(actual.getId()).orElse(actual);
        String estado = finalIntento.getEstado();
        int usados = finalIntento.getIntentos();
        boolean pendiente = "pendiente".equals(estado);
        boolean compasivo = "compasivo".equals(modoDe(leccion));
        boolean correcto = intentoRealizado ? correctoEnEsteIntento : "acertado".equals(estado);

        String pista = null;
        if (pendiente && usados > 0 && compasivo) {
            pista = pistaPara(ejercicio, usados);
        }

        ResumenEjercicios resumen = resumen(usuarioId, leccion);

        Map<String, Object> cuerpo = new LinkedHashMap<>();
        cuerpo.put("correcto", correcto);
        cuerpo.put("estado", estado);
        cuerpo.put("intentosUsados", usados);
        cuerpo.put("intentosRestantes", pendiente ? Math.max(0, MAX_INTENTOS - usados) : 0);
        cuerpo.put("pista", pista);
        cuerpo.put("respuestaCorrecta",
                !conversacion && "revelado".equals(estado) ? primeraRespuesta(ejercicio) : null);
        cuerpo.put("aciertos", resumen.getAciertos());
        cuerpo.put("total", resumen.getTotal());
        cuerpo.put("bonusXp", resumen.getBonusXp());
        cuerpo.put("todosCerrados", resumen.isTodosCerrados());

        if (conversacion) {
            int correctos = intentoRealizado ? correctosEnIntento : ("acertado".equals(estado) ? huecos.size() : 0);
            boolean mostrarIncorrectos = intentoRealizado && pendiente && compasivo;
            cuerpo.put("correctos", correctos);
            cuerpo.put("totalHuecos", huecos.size());
            cuerpo.put("incorrectos", mostrarIncorrectos ? incorrectosEnIntento : new ArrayList<Integer>());
            cuerpo.put("solucion", pendiente ? new ArrayList<String>() : huecos);
        }
        return cuerpo;
    }

    private boolean esConversacion(Ejercicio ejercicio) {
        return "conversacion".equals(ejercicio.getTipo());
    }

    private List<String> textosDeHuecos(Ejercicio ejercicio) {
        List<String> huecos = new ArrayList<>();
        if (ejercicio.getTurnos() != null) {
            for (TurnoEjercicio turno : ejercicio.getTurnos()) {
                if (turno.tieneHueco()) {
                    huecos.add(turno.getHueco());
                }
            }
        }
        return huecos;
    }

    private List<TurnoVista> construirTurnos(Ejercicio ejercicio) {
        List<TurnoVista> turnos = new ArrayList<>();
        if (ejercicio.getTurnos() == null) {
            return turnos;
        }
        int indiceHueco = 0;
        for (TurnoEjercicio turno : ejercicio.getTurnos()) {
            if (turno.tieneHueco()) {
                turnos.add(new TurnoVista(turno.getHablante(), null, true, indiceHueco));
                indiceHueco++;
            } else {
                turnos.add(new TurnoVista(turno.getHablante(), turno.getTexto(), false, null));
            }
        }
        return turnos;
    }

    private List<String> construirBloques(Ejercicio ejercicio, List<String> huecos) {
        List<String> bloques = new ArrayList<>(huecos);
        if (ejercicio.getDistractores() != null) {
            for (String distractor : ejercicio.getDistractores()) {
                if (distractor != null && !distractor.isBlank()) {
                    bloques.add(distractor);
                }
            }
        }
        Collections.shuffle(bloques);
        return bloques;
    }

    private List<String> leerRespuestasConversacion(String respuesta, int totalHuecos) {
        if (totalHuecos == 0) {
            throw new IllegalArgumentException("El ejercicio no tiene huecos");
        }

        List<String> lista;
        try {
            lista = objectMapper.readValue(respuesta, new TypeReference<List<String>>() {
            });
        } catch (RuntimeException e) {
            throw new IllegalArgumentException("La respuesta debe ser un arreglo JSON de textos");
        }

        if (lista == null || lista.size() != totalHuecos) {
            throw new IllegalArgumentException("La cantidad de respuestas no coincide con los huecos");
        }

        List<String> limpia = new ArrayList<>();
        boolean algunaConTexto = false;
        for (String texto : lista) {
            String valor = texto != null ? texto : "";
            if (!valor.isBlank()) {
                algunaConTexto = true;
            }
            limpia.add(valor);
        }
        if (!algunaConTexto) {
            throw new IllegalArgumentException("La respuesta está vacía");
        }
        return limpia;
    }

    private IntentoEjercicio obtenerOCrear(String usuarioId, String leccionId, int indice) {
        IntentoEjercicio existente = intentoRepositorio
                .findByUsuarioIdAndLeccionIdAndIndice(usuarioId, leccionId, indice);
        if (existente != null) {
            return existente;
        }

        IntentoEjercicio nuevo = new IntentoEjercicio();
        nuevo.setUsuarioId(usuarioId);
        nuevo.setLeccionId(leccionId);
        nuevo.setIndice(indice);
        nuevo.setIntentos(0);
        nuevo.setEstado("pendiente");
        nuevo.setIntentoAcierto(0);

        try {
            return intentoRepositorio.save(nuevo);
        } catch (DuplicateKeyException e) {
            return intentoRepositorio.findByUsuarioIdAndLeccionIdAndIndice(usuarioId, leccionId, indice);
        }
    }

    private void cerrar(String id, String estado, int intentoAcierto) {
        Query consulta = Query.query(Criteria.where("id").is(id).and("estado").is("pendiente"));
        mongoTemplate.updateFirst(consulta,
                new Update().set("estado", estado).set("intentoAcierto", intentoAcierto),
                IntentoEjercicio.class);
    }

    private Map<Integer, IntentoEjercicio> mapaDeIntentos(String usuarioId, String leccionId) {
        Map<Integer, IntentoEjercicio> mapa = new HashMap<>();
        for (IntentoEjercicio intento : intentoRepositorio.findByUsuarioIdAndLeccionId(usuarioId, leccionId)) {
            mapa.put(intento.getIndice(), intento);
        }
        return mapa;
    }

    private int bonusPorIntento(int intento) {
        return switch (intento) {
            case 1 -> bonusIntento1;
            case 2 -> bonusIntento2;
            case 3 -> bonusIntento3;
            default -> 0;
        };
    }

    private boolean coincide(Ejercicio ejercicio, String respuesta) {
        if (ejercicio.getRespuestas() == null) {
            return false;
        }
        String delUsuario = normalizar(respuesta);
        if (delUsuario.isEmpty()) {
            return false;
        }
        for (String correcta : ejercicio.getRespuestas()) {
            if (correcta != null && delUsuario.equals(normalizar(correcta))) {
                return true;
            }
        }
        return false;
    }

    private String normalizar(String texto) {
        if (texto == null) {
            return "";
        }
        String t = texto.toLowerCase(Locale.ROOT).trim();
        t = t.replaceAll("[\u2019\u2018`\u00B4]", "'");
        t = t.replaceAll("[,.!?;:\u00BF\u00A1]", "");
        t = t.replaceAll("\\s+", " ").trim();
        return t;
    }

    private String primeraRespuesta(Ejercicio ejercicio) {
        if (ejercicio.getRespuestas() == null || ejercicio.getRespuestas().isEmpty()) {
            return "";
        }
        String primera = ejercicio.getRespuestas().get(0);
        return primera != null ? primera : "";
    }

    private String pistaPara(Ejercicio ejercicio, int fallo) {
        List<String> pistas = ejercicio.getPistas();
        if (pistas != null && fallo >= 1 && fallo <= pistas.size()) {
            String pista = pistas.get(fallo - 1);
            if (pista != null && !pista.isBlank()) {
                return pista;
            }
        }

        String base = primeraRespuesta(ejercicio).trim();
        if (base.isEmpty()) {
            return null;
        }
        String[] palabras = base.split("\\s+");
        if (fallo == 1) {
            return "La respuesta tiene " + palabras.length + (palabras.length == 1 ? " palabra." : " palabras.");
        }
        if (fallo == 2) {
            return "Empieza con \u00AB" + palabras[0] + "\u00BB.";
        }
        return null;
    }
}