package com.lexavoxa.app.controlador;

import com.lexavoxa.app.modelo.Curso;
import com.lexavoxa.app.modelo.Leccion;
import com.lexavoxa.app.modelo.Rango;
import com.lexavoxa.app.modelo.Usuario;
import com.lexavoxa.app.servicio.CursoProgresoView;
import com.lexavoxa.app.servicio.CursoServicio;
import com.lexavoxa.app.servicio.LeccionNodoView;
import com.lexavoxa.app.servicio.LeccionServicio;
import com.lexavoxa.app.servicio.ProgresoServicio;
import com.lexavoxa.app.servicio.RangoServicio;
import com.lexavoxa.app.servicio.TestServicio;
import com.lexavoxa.app.servicio.UsuarioServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collectors;

@Controller
public class CursoControlador {

    @Autowired
    private CursoServicio cursoServicio;

    @Autowired
    private LeccionServicio leccionServicio;

    @Autowired
    private UsuarioServicio usuarioServicio;

    @Autowired
    private RangoServicio rangoServicio;

    @Autowired
    private ProgresoServicio progresoServicio;

    @Autowired
    private TestServicio testServicio;

    @GetMapping("/cursos")
    public String listarCursos(Model model) {
        model.addAttribute("cursos", cursoServicio.listarCursos());
        model.addAttribute("rangos", rangoServicio.listarRangos());
        return "cursos";
    }

    @PostMapping("/cursos/crear")
    public String crearCurso(@RequestParam String idioma,
                             @RequestParam String nombre,
                             @RequestParam String descripcion,
                             @RequestParam int orden,
                             @RequestParam String rangoId) {
        Curso curso = new Curso();
        curso.setIdioma(idioma);
        curso.setNombre(nombre);
        curso.setDescripcion(descripcion);
        curso.setOrden(orden);
        curso.setRangoId(rangoId);
        cursoServicio.guardarCurso(curso);
        return "redirect:/cursos";
    }

    @GetMapping("/cursos/eliminar/{id}")
    public String eliminarCurso(@PathVariable String id) {
        cursoServicio.eliminarCurso(id);
        return "redirect:/cursos";
    }

    @GetMapping("/cursos/{id}/lecciones")
    public String verLeccionesDeCurso(@PathVariable String id, Authentication authentication, Model model) {
        Usuario usuario = usuarioServicio.obtenerUsuarioPorEmail(authentication.getName());
        Curso curso = cursoServicio.obtenerCursoPorId(id);

        if (curso == null || testServicio.cursoBloqueado(usuario.getId(), curso)) {
            return "redirect:/cursos-disponibles";
        }

        List<LeccionNodoView> nodos = progresoServicio.obtenerNodosDeCurso(usuario.getId(), id);

        int totalLecciones = leccionServicio.listarLeccionesPorCurso(id).size();
        boolean todasCompletas = totalLecciones > 0
                && progresoServicio.contarLeccionesCompletadasEnCurso(usuario.getId(), id) == totalLecciones;

        boolean testAprobado = testServicio.cursoAprobado(usuario.getId(), id);

        model.addAttribute("curso", curso);
        model.addAttribute("nodos", nodos);
        model.addAttribute("todasCompletas", todasCompletas);
        model.addAttribute("testAprobado", testAprobado);
        return "curso";
    }

    @PostMapping("/lecciones/{id}/completar")
    public String completarLeccion(@PathVariable String id, Authentication authentication) {
        Usuario usuario = usuarioServicio.obtenerUsuarioPorEmail(authentication.getName());
        Leccion leccion = leccionServicio.obtenerLeccionPorId(id);

        if (leccion == null) {
            return "redirect:/cursos-disponibles";
        }

        Curso curso = cursoServicio.obtenerCursoPorId(leccion.getCursoId());
        if (curso == null || testServicio.cursoBloqueado(usuario.getId(), curso)) {
            return "redirect:/cursos-disponibles";
        }

        progresoServicio.completarLeccion(usuario.getId(), id);

        return "redirect:/cursos/" + leccion.getCursoId() + "/lecciones";
    }

    @GetMapping("/mis-cursos")
    public String verMisCursos(Authentication authentication, Model model) {
        Usuario usuario = usuarioServicio.obtenerUsuarioPorEmail(authentication.getName());
        Rango rango = usuario != null ? rangoServicio.obtenerRangoPorId(usuario.getRangoId()) : null;
        Rango siguienteRango = rango != null ? rangoServicio.obtenerSiguienteRango(rango) : null;
        Curso cursoActivo = usuario != null ? cursoServicio.obtenerCursoPorId(usuario.getCursoActivoId()) : null;
        int posicion = usuario != null ? usuarioServicio.obtenerPosicionEnRanking(usuario.getId()) : -1;

        int porcentajeXp = 100;
        int xpFaltante = 0;
        if (usuario != null && siguienteRango != null) {
            porcentajeXp = Math.min(100, usuario.getExperiencia() * 100 / siguienteRango.getPuntosRequeridos());
            xpFaltante = Math.max(0, siguienteRango.getPuntosRequeridos() - usuario.getExperiencia());
        }

        int totalLecciones = 0;
        int leccionesCompletadas = 0;
        int porcentajeCurso = 0;
        if (usuario != null && cursoActivo != null) {
            totalLecciones = leccionServicio.listarLeccionesPorCurso(cursoActivo.getId()).size();
            leccionesCompletadas = progresoServicio.contarLeccionesCompletadasEnCurso(usuario.getId(), cursoActivo.getId());
            porcentajeCurso = totalLecciones > 0 ? (leccionesCompletadas * 100 / totalLecciones) : 0;
        }

        boolean objetivoLeccion = usuario != null && progresoServicio.contarLeccionesCompletadasEnSemana(usuario.getId()) >= 1;
        boolean objetivoXp = usuario != null && progresoServicio.obtenerXpGanadoEnSemana(usuario.getId()) >= 100;
        boolean objetivoRacha = usuario != null && usuario.getRachaActual() > 0;
        int objetivosCompletados = (objetivoLeccion ? 1 : 0) + (objetivoXp ? 1 : 0) + (objetivoRacha ? 1 : 0);

        model.addAttribute("usuario", usuario);
        model.addAttribute("rango", rango);
        model.addAttribute("siguienteRango", siguienteRango);
        model.addAttribute("porcentajeXp", porcentajeXp);
        model.addAttribute("xpFaltante", xpFaltante);
        model.addAttribute("cursoActivo", cursoActivo);
        model.addAttribute("totalLecciones", totalLecciones);
        model.addAttribute("leccionesCompletadas", leccionesCompletadas);
        model.addAttribute("porcentajeCurso", porcentajeCurso);
        model.addAttribute("posicionRanking", posicion);
        model.addAttribute("feed", usuario != null ? progresoServicio.obtenerFeedReciente(usuario.getId(), 5) : List.of());
        model.addAttribute("objetivoLeccion", objetivoLeccion);
        model.addAttribute("objetivoXp", objetivoXp);
        model.addAttribute("objetivoRacha", objetivoRacha);
        model.addAttribute("objetivosCompletados", objetivosCompletados);

        LinkedHashMap<String, Integer> actividadVacia = new LinkedHashMap<>();
        for (String dia : new String[]{"Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"}) {
            actividadVacia.put(dia, 0);
        }
        model.addAttribute("actividadSemana", usuario != null ? progresoServicio.obtenerActividadUltimos7Dias(usuario.getId()) : actividadVacia);
        return "mis-cursos";
    }

    @GetMapping({"/cursos-disponibles", "/cursos-disponibles/{id}"})
    public String verCursosDisponibles(@PathVariable(required = false) String id,
                                       @RequestParam(required = false, defaultValue = "todos") String filtro,
                                       Authentication authentication, Model model) {
        Usuario usuario = usuarioServicio.obtenerUsuarioPorEmail(authentication.getName());
        String idioma = usuario.getIdiomas() != null && !usuario.getIdiomas().isEmpty()
                ? usuario.getIdiomas().get(0) : null;

        List<Curso> cursos = idioma != null
                ? cursoServicio.listarCursosPorIdiomaYRango(idioma, usuario.getRangoId())
                : cursoServicio.listarCursos();

        Rango rangoActual = rangoServicio.obtenerRangoPorId(usuario.getRangoId());
        String rangoNombre = rangoActual != null ? rangoActual.getNombre() : "";

        List<CursoProgresoView> cursosConProgreso = new ArrayList<>();
        for (Curso curso : cursos) {
            int total = leccionServicio.listarLeccionesPorCurso(curso.getId()).size();
            int completadas = progresoServicio.contarLeccionesCompletadasEnCurso(usuario.getId(), curso.getId());
            CursoProgresoView vista = new CursoProgresoView(curso, rangoNombre, total, completadas);
            vista.setBloqueado(testServicio.cursoBloqueado(usuario.getId(), curso));
            cursosConProgreso.add(vista);
        }

        List<CursoProgresoView> filtrados = cursosConProgreso.stream()
                .filter(c -> switch (filtro) {
                    case "progreso" -> c.getEstado().equals("progreso");
                    case "completados" -> c.getEstado().equals("completado");
                    default -> true;
                })
                .collect(Collectors.toList());

        String idParaMostrar = id != null ? id : usuario.getCursoActivoId();
        Curso cursoParaMostrar = cursoServicio.obtenerCursoPorId(idParaMostrar);

        CursoProgresoView cursoMostradoView = null;
        boolean esElActivo = false;
        if (cursoParaMostrar != null) {
            int total = leccionServicio.listarLeccionesPorCurso(cursoParaMostrar.getId()).size();
            int completadas = progresoServicio.contarLeccionesCompletadasEnCurso(usuario.getId(), cursoParaMostrar.getId());
            cursoMostradoView = new CursoProgresoView(cursoParaMostrar, rangoNombre, total, completadas);
            cursoMostradoView.setBloqueado(testServicio.cursoBloqueado(usuario.getId(), cursoParaMostrar));
            esElActivo = cursoParaMostrar.getId().equals(usuario.getCursoActivoId());
        }

        model.addAttribute("cursos", filtrados);
        model.addAttribute("cursoMostrado", cursoMostradoView);
        model.addAttribute("esElActivo", esElActivo);
        model.addAttribute("filtro", filtro);
        return "cursos-disponibles";
    }

    @PostMapping("/cursos-disponibles/elegir/{id}")
    public String elegirCurso(@PathVariable String id, Authentication authentication) {
        Usuario usuario = usuarioServicio.obtenerUsuarioPorEmail(authentication.getName());
        Curso curso = cursoServicio.obtenerCursoPorId(id);

        boolean idiomaValido = curso != null && usuario.getIdiomas() != null
                && usuario.getIdiomas().stream().anyMatch(i -> i.equalsIgnoreCase(curso.getIdioma()));
        boolean rangoValido = curso != null && curso.getRangoId() != null
                && curso.getRangoId().equals(usuario.getRangoId());

        if (!idiomaValido || !rangoValido || testServicio.cursoBloqueado(usuario.getId(), curso)) {
            return "redirect:/cursos-disponibles";
        }

        usuarioServicio.elegirCursoActivo(usuario.getId(), id);
        return "redirect:/cursos/" + id + "/lecciones";
    }
}