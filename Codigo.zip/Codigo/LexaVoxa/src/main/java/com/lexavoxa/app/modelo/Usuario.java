package com.lexavoxa.app.modelo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.util.List;

@Document(collection = "Usuarios")
public class Usuario {

    @Id
    private String id;
    private String nombre;
    private String nombreUsuario;
    private int edad;
    private String email;
    private String contrasena;
    private List<String> idiomas;
    private String rangoId;
    private String cursoActivoId;
    private int experiencia;
    private String rol;
    private int metaDiaria;
    private int rachaActual;
    private LocalDate ultimaActividad;

    public Usuario() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public List<String> getIdiomas() {
        return idiomas;
    }

    public void setIdiomas(List<String> idiomas) {
        this.idiomas = idiomas;
    }

    public String getRangoId() {
        return rangoId;
    }

    public void setRangoId(String rangoId) {
        this.rangoId = rangoId;
    }

    public String getCursoActivoId() {
        return cursoActivoId;
    }

    public void setCursoActivoId(String cursoActivoId) {
        this.cursoActivoId = cursoActivoId;
    }

    public int getExperiencia() {
        return experiencia;
    }

    public void setExperiencia(int experiencia) {
        this.experiencia = experiencia;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public int getMetaDiaria() {
        return metaDiaria;
    }

    public void setMetaDiaria(int metaDiaria) {
        this.metaDiaria = metaDiaria;
    }

    public int getRachaActual() {
        return rachaActual;
    }

    public void setRachaActual(int rachaActual) {
        this.rachaActual = rachaActual;
    }

    public LocalDate getUltimaActividad() {
        return ultimaActividad;
    }

    public void setUltimaActividad(LocalDate ultimaActividad) {
        this.ultimaActividad = ultimaActividad;
    }
}
// here we go