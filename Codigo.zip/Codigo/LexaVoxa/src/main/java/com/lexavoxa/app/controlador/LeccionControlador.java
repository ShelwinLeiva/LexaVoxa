package com.lexavoxa.app.controlador;

import com.lexavoxa.app.modelo.Curso;
import com.lexavoxa.app.modelo.Ejercicio;
import com.lexavoxa.app.modelo.Leccion;
import com.lexavoxa.app.modelo.PaginaLeccion;
import com.lexavoxa.app.modelo.Rango;
import com.lexavoxa.app.modelo.Usuario;
import com.lexavoxa.app.servicio.CursoServicio;
import com.lexavoxa.app.servicio.EjercicioServicio;
import com.lexavoxa.app.servicio.LeccionServicio;
import com.lexavoxa.app.servicio.ProgresoServicio;
import com.lexavoxa.app.servicio.RangoServicio;
import com.lexavoxa.app.servicio.TestServicio;
import com.lexavoxa.app.servicio.UsuarioServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Controller
public class LeccionControlador {

    @Autowired
    private LeccionServicio leccionServicio;

    @Autowired
    private CursoServicio cursoServicio;

    @Autowired
    private UsuarioServicio usuarioServicio;

    @Autowired
    private RangoServicio rangoServicio;

    @Autowired
    private ProgresoServicio progresoServicio;

    @Autowired
    private TestServicio testServicio;

    @Autowired
    private EjercicioServicio ejercicioServicio;

    @GetMapping("/lecciones")
    public String listarLecciones(Model model) {
        model.addAttribute("lecciones", leccionServicio.listarLecciones());
        return "lecciones";
    }

    @PostMapping("/lecciones/crear")
    public String crearLeccion(@RequestParam int orden,
                               @RequestParam String nombre,
                               @RequestParam String tipo,
                               @RequestParam String descripcion,
                               @RequestParam int tiempoEstimadoMinutos,
                               @RequestParam int xpOtorgado,
                               @RequestParam String cursoId) {
        Leccion leccion = new Leccion();
        leccion.setOrden(orden);
        leccion.setNombre(nombre);
        leccion.setTipo(tipo);
        leccion.setDescripcion(descripcion);
        leccion.setTiempoEstimadoMinutos(tiempoEstimadoMinutos);
        leccion.setXpOtorgado(xpOtorgado);
        leccion.setCursoId(cursoId);
        leccionServicio.guardarLeccion(leccion);
        return "redirect:/lecciones";
    }

    @GetMapping("/lecciones/eliminar/{id}")
    public String eliminarLeccion(@PathVariable String id) {
        leccionServicio.eliminarLeccion(id);
        return "redirect:/lecciones";
    }

    @GetMapping("/lecciones/{id}/ver")
    public String verLeccion(@PathVariable String id,
                             @RequestParam(defaultValue = "1") int pagina,
                             Authentication authentication,
                             Model model) {
        Usuario usuario = usuarioServicio.obtenerUsuarioPorEmail(authentication.getName());
        Leccion leccion = leccionServicio.obtenerLeccionPorId(id);

        if (leccion == null) {
            return "redirect:/cursos-disponibles";
        }

        Curso curso = cursoServicio.obtenerCursoPorId(leccion.getCursoId());
        if (curso == null || testServicio.cursoBloqueado(usuario.getId(), curso)) {
            return "redirect:/cursos-disponibles";
        }

        String estado = progresoServicio.calcularEstados(usuario.getId(), curso.getId()).get(id);
        if (estado == null || "bloqueada".equals(estado)) {
            return "redirect:/cursos/" + curso.getId() + "/lecciones";
        }

        Rango rango = rangoServicio.obtenerRangoPorId(curso.getRangoId());
        String rangoNombre = rango != null ? rango.getNombre() : "";
        boolean completada = "completada".equals(estado);

        if (!"contenido".equals(leccion.getTipo())) {
            model.addAttribute("leccion", copiaSinEjercicios(leccion));
            model.addAttribute("curso", curso);
            model.addAttribute("rangoNombre", rangoNombre);
            model.addAttribute("completada", completada);
            model.addAttribute("modo", ejercicioServicio.modoDe(leccion));
            model.addAttribute("ejercicios", ejercicioServicio.construirVistas(usuario.getId(), leccion));
            model.addAttribute("resumen", ejercicioServicio.resumen(usuario.getId(), leccion));
            return "ejercicios";
        }

        List<PaginaLeccion> paginas = leccion.getPaginas();
        if (paginas == null || paginas.isEmpty()) {
            PaginaLeccion unica = new PaginaLeccion();
            unica.setTitulo(leccion.getNombre());
            unica.setIntroduccion(leccion.getDescripcion());
            unica.setVocabulario(leccion.getPalabras());
            paginas = List.of(unica);
        }

        int totalPaginas = paginas.size();
        int paginaValida = Math.max(1, Math.min(pagina, totalPaginas));

        model.addAttribute("leccion", leccion);
        model.addAttribute("curso", curso);
        model.addAttribute("rangoNombre", rangoNombre);
        model.addAttribute("paginaActual", paginas.get(paginaValida - 1));
        model.addAttribute("pagina", paginaValida);
        model.addAttribute("totalPaginas", totalPaginas);
        model.addAttribute("completada", completada);
        return "leccion";
    }

    @PostMapping("/lecciones/{id}/ejercicios/{indice}/responder")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> responderEjercicio(@PathVariable String id,
                                                                  @PathVariable int indice,
                                                                  @RequestParam(required = false) String respuesta,
                                                                  Authentication authentication) {
        Usuario usuario = usuarioServicio.obtenerUsuarioPorEmail(authentication.getName());
        Leccion leccion = leccionServicio.obtenerLeccionPorId(id);

        if (leccion == null) {
            return error(HttpStatus.NOT_FOUND, "Lección no encontrada");
        }

        Curso curso = cursoServicio.obtenerCursoPorId(leccion.getCursoId());
        if (curso == null || testServicio.cursoBloqueado(usuario.getId(), curso)) {
            return error(HttpStatus.FORBIDDEN, "Lección bloqueada");
        }

        String estado = progresoServicio.calcularEstados(usuario.getId(), curso.getId()).get(id);
        if (estado == null || "bloqueada".equals(estado)) {
            return error(HttpStatus.FORBIDDEN, "Lección bloqueada");
        }

        List<Ejercicio> ejercicios = leccion.getEjercicios();
        if (ejercicios == null || indice < 0 || indice >= ejercicios.size()) {
            return error(HttpStatus.NOT_FOUND, "Ejercicio no encontrado");
        }

        if (respuesta == null || respuesta.isBlank()) {
            return error(HttpStatus.BAD_REQUEST, "La respuesta está vacía");
        }

        Map<String, Object> cuerpo = ejercicioServicio.responder(usuario.getId(), leccion, indice,
                respuesta, "completada".equals(estado));
        return ResponseEntity.ok(cuerpo);
    }

    private ResponseEntity<Map<String, Object>> error(HttpStatus estado, String mensaje) {
        Map<String, Object> cuerpo = new LinkedHashMap<>();
        cuerpo.put("error", mensaje);
        return ResponseEntity.status(estado).body(cuerpo);
    }

    private Leccion copiaSinEjercicios(Leccion origen) {
        Leccion copia = new Leccion();
        copia.setId(origen.getId());
        copia.setNombre(origen.getNombre());
        copia.setTipo(origen.getTipo());
        copia.setOrden(origen.getOrden());
        copia.setDescripcion(origen.getDescripcion());
        copia.setTiempoEstimadoMinutos(origen.getTiempoEstimadoMinutos());
        copia.setXpOtorgado(origen.getXpOtorgado());
        copia.setPalabras(origen.getPalabras());
        copia.setPaginas(origen.getPaginas());
        copia.setModo(origen.getModo());
        copia.setCursoId(origen.getCursoId());
        return copia;
    }
}