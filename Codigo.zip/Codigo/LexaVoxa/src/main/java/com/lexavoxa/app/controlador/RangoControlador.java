package com.lexavoxa.app.controlador;

import com.lexavoxa.app.modelo.Rango;
import com.lexavoxa.app.servicio.RangoServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class RangoControlador {

    @Autowired
    private RangoServicio rangoServicio;

    @GetMapping("/rangos")
    public String listarRangos(Model model) {
        model.addAttribute("rangos", rangoServicio.listarRangos());
        return "rangos";
    }

    @PostMapping("/rangos/crear")
    public String crearRango(@RequestParam String nombre,
                             @RequestParam int puntosRequeridos) {
        Rango rango = new Rango();
        rango.setNombre(nombre);
        rango.setPuntosRequeridos(puntosRequeridos);
        rangoServicio.guardarRango(rango);
        return "redirect:/rangos";
    }

    @GetMapping("/rangos/eliminar/{id}")
    public String eliminarRango(@PathVariable String id) {
        rangoServicio.eliminarRango(id);
        return "redirect:/rangos";
    }
}
