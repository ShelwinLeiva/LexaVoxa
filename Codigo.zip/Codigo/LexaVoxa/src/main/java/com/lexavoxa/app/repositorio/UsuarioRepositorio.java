package com.lexavoxa.app.repositorio;

import com.lexavoxa.app.modelo.Usuario;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface UsuarioRepositorio extends MongoRepository<Usuario, String> {
    Usuario findByEmail(String email);
    Usuario findByNombreUsuario(String nombreUsuario);
}