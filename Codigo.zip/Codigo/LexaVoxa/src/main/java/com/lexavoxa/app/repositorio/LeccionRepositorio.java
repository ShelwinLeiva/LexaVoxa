package com.lexavoxa.app.repositorio;

import com.lexavoxa.app.modelo.Leccion;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface LeccionRepositorio extends MongoRepository<Leccion, String> {
    List<Leccion> findByCursoIdOrderByOrdenAsc(String cursoId);
}