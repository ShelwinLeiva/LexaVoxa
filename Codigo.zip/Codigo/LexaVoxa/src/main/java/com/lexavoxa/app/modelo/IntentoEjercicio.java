package com.lexavoxa.app.modelo;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "IntentosEjercicio")
@CompoundIndex(name = "usuario_leccion_indice", def = "{'usuarioId': 1, 'leccionId': 1, 'indice': 1}", unique = true)
public class IntentoEjercicio {

    @Id
    private String id;
    private String usuarioId;
    private String leccionId;
    private int indice;
    private int intentos;
    private String estado;
    private int intentoAcierto;

    public IntentoEjercicio() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(String usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getLeccionId() {
        return leccionId;
    }

    public void setLeccionId(String leccionId) {
        this.leccionId = leccionId;
    }

    public int getIndice() {
        return indice;
    }

    public void setIndice(int indice) {
        this.indice = indice;
    }

    public int getIntentos() {
        return intentos;
    }

    public void setIntentos(int intentos) {
        this.intentos = intentos;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getIntentoAcierto() {
        return intentoAcierto;
    }

    public void setIntentoAcierto(int intentoAcierto) {
        this.intentoAcierto = intentoAcierto;
    }
}