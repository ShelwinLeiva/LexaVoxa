package com.lexavoxa.app.config;

import tools.jackson.core.type.TypeReference;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import com.lexavoxa.app.modelo.Curso;
import com.lexavoxa.app.modelo.Ejercicio;
import com.lexavoxa.app.modelo.Test;
import com.lexavoxa.app.repositorio.CursoRepositorio;
import com.lexavoxa.app.repositorio.TestRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Component
@Order(5)
public class TestSeeder implements CommandLineRunner {

    private static final String ARCHIVO = "contenido/introductions/12-final-test.json";

    @Autowired
    private TestRepositorio testRepositorio;

    @Autowired
    private CursoRepositorio cursoRepositorio;

    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public void run(String... args) {
        Curso curso = cursoRepositorio.findAll()
                .stream()
                .filter(c -> "Introductions".equals(c.getNombre()) && "inglés".equalsIgnoreCase(c.getIdioma()))
                .findFirst()
                .orElse(null);

        if (curso == null) {
            return;
        }

        Resource recurso = new ClassPathResource(ARCHIVO);
        if (!recurso.exists()) {
            return;
        }

        List<Ejercicio> ejercicios = leerEjercicios(recurso);
        if (ejercicios.isEmpty()) {
            return;
        }

        Test test = testRepositorio.findByCursoId(curso.getId());
        if (test == null) {
            test = new Test();
        }
        test.setCursoId(curso.getId());
        test.setEjercicios(ejercicios);
        test.setPreguntaIds(new ArrayList<>());
        test.setXpOtorgado(50);
        test.setPuntajeMinimoAprobacion(70);
        testRepositorio.save(test);
    }

    private List<Ejercicio> leerEjercicios(Resource recurso) {
        try (InputStream entrada = recurso.getInputStream()) {
            JsonNode raiz = objectMapper.readTree(entrada);
            JsonNode nodo = raiz.get("ejercicios");
            if (nodo == null || nodo.isNull()) {
                return new ArrayList<>();
            }

            List<Ejercicio> ejercicios = objectMapper.convertValue(nodo, new TypeReference<List<Ejercicio>>() {
            });

            for (int i = 0; i < ejercicios.size(); i++) {
                Ejercicio ejercicio = ejercicios.get(i);
                if (ejercicio.getAudioTexto() != null && !ejercicio.getAudioTexto().isBlank()) {
                    ejercicio.setAudioUrl("/audio/introductions/12/" + (i + 1) + ".mp3");
                }
            }
            return ejercicios;
        } catch (IOException | RuntimeException e) {
            throw new IllegalStateException("Error leyendo el contenido " + ARCHIVO, e);
        }
    }
}