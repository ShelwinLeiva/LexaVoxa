package com.lexavoxa.app.servicio;

import com.lexavoxa.app.modelo.ResultadoTest;

import java.util.List;

public class CorreccionTest {

    private final ResultadoTest resultado;
    private final int aciertos;
    private final int total;
    private final List<RevisionPregunta> revision;
    private final boolean yaAprobado;

    public CorreccionTest(ResultadoTest resultado, int aciertos, int total,
                          List<RevisionPregunta> revision, boolean yaAprobado) {
        this.resultado = resultado;
        this.aciertos = aciertos;
        this.total = total;
        this.revision = revision;
        this.yaAprobado = yaAprobado;
    }

    public ResultadoTest getResultado() {
        return resultado;
    }

    public int getAciertos() {
        return aciertos;
    }

    public int getTotal() {
        return total;
    }

    public List<RevisionPregunta> getRevision() {
        return revision;
    }

    public boolean isYaAprobado() {
        return yaAprobado;
    }
}