package com.lexavoxa.app.config;

import com.lexavoxa.app.modelo.Curso;
import com.lexavoxa.app.modelo.Rango;
import com.lexavoxa.app.repositorio.CursoRepositorio;
import com.lexavoxa.app.repositorio.RangoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Order(2)
public class CursoSeeder implements CommandLineRunner {

    @Autowired
    private CursoRepositorio cursoRepositorio;

    @Autowired
    private RangoRepositorio rangoRepositorio;

    @Override
    public void run(String... args) {
        Rango bronce = rangoRepositorio.findAll()
                .stream()
                .min((r1, r2) -> Integer.compare(r1.getPuntosRequeridos(), r2.getPuntosRequeridos()))
                .orElse(null);

        if (bronce == null) {
            return;
        }

        String bronceId = bronce.getId();
        List<Curso> existentes = cursoRepositorio.findAll();

        guardar(existentes, "inglés", "Introductions",
                "Presentarte y hablar de información personal y gustos.", bronceId, 1);
        guardar(existentes, "inglés", "My Family & Friends",
                "Habla de tu familia y tus amigos con vocabulario básico.", bronceId, 2);
        guardar(existentes, "inglés", "My Home",
                "Describe tu casa, sus espacios y los objetos que hay en ella.", bronceId, 3);
        guardar(existentes, "inglés", "My Daily Life",
                "Cuenta tu rutina diaria y las horas del día.", bronceId, 4);
        guardar(existentes, "inglés", "Food & Drinks",
                "Aprende a hablar de comida, bebidas y a pedir en un restaurante.", bronceId, 5);
        guardar(existentes, "inglés", "Everyday English",
                "Frases clave para desenvolverte en situaciones del día a día.", bronceId, 6);

        for (String idioma : List.of("francés", "portugués")) {
            guardar(existentes, idioma, "Primeros pasos",
                    "Aprende lo básico: saludos, presentaciones y vocabulario esencial.", bronceId, 1);
            guardar(existentes, idioma, "Vocabulario esencial",
                    "Amplía tu vocabulario con palabras de uso cotidiano.", bronceId, 2);
            guardar(existentes, idioma, "Frases cotidianas",
                    "Frases clave para desenvolverte en situaciones del día a día.", bronceId, 3);
        }
    }

    private void guardar(List<Curso> existentes, String idioma, String nombre,
                         String descripcion, String rangoId, int orden) {
        Curso curso = existentes.stream()
                .filter(c -> c.getIdioma() != null && c.getIdioma().equalsIgnoreCase(idioma))
                .filter(c -> rangoId.equals(c.getRangoId()))
                .filter(c -> c.getOrden() == orden)
                .findFirst()
                .orElse(new Curso());

        curso.setIdioma(idioma);
        curso.setNombre(nombre);
        curso.setDescripcion(descripcion);
        curso.setRangoId(rangoId);
        curso.setOrden(orden);
        cursoRepositorio.save(curso);
    }
}