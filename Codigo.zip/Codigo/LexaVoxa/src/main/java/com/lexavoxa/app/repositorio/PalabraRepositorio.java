package com.lexavoxa.app.repositorio;

import com.lexavoxa.app.modelo.Palabra;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PalabraRepositorio extends MongoRepository<Palabra, String> {
}
