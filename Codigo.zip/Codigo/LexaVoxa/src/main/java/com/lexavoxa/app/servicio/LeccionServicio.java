package com.lexavoxa.app.servicio;

import com.lexavoxa.app.modelo.Leccion;
import com.lexavoxa.app.repositorio.LeccionRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LeccionServicio {

    @Autowired
    private LeccionRepositorio leccionRepositorio;

    public List<Leccion> listarLecciones() {
        return leccionRepositorio.findAll();
    }

    public Leccion guardarLeccion(Leccion leccion) {
        return leccionRepositorio.save(leccion);
    }

    public void eliminarLeccion(String id) {
        leccionRepositorio.deleteById(id);
    }

    public List<Leccion> listarLeccionesPorCurso(String cursoId) {
        return leccionRepositorio.findByCursoIdOrderByOrdenAsc(cursoId);
    }

    public Leccion obtenerLeccionPorId(String id) {
        if (id == null) {
            return null;
        }
        return leccionRepositorio.findById(id).orElse(null);
    }
}