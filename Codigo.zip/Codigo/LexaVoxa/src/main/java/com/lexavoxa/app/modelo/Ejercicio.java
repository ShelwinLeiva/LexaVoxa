package com.lexavoxa.app.modelo;

import java.util.List;

public class Ejercicio {

    private String tipo;
    private String enunciado;
    private String audioTexto;
    private String audioUrl;
    private List<String> opciones;
    private List<String> respuestas;
    private List<String> pistas;
    private List<TurnoEjercicio> turnos;
    private List<String> distractores;
    private String explicacion;

    public Ejercicio() {
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getEnunciado() {
        return enunciado;
    }

    public void setEnunciado(String enunciado) {
        this.enunciado = enunciado;
    }

    public String getAudioTexto() {
        return audioTexto;
    }

    public void setAudioTexto(String audioTexto) {
        this.audioTexto = audioTexto;
    }

    public String getAudioUrl() {
        return audioUrl;
    }

    public void setAudioUrl(String audioUrl) {
        this.audioUrl = audioUrl;
    }

    public List<String> getOpciones() {
        return opciones;
    }

    public void setOpciones(List<String> opciones) {
        this.opciones = opciones;
    }

    public List<String> getRespuestas() {
        return respuestas;
    }

    public void setRespuestas(List<String> respuestas) {
        this.respuestas = respuestas;
    }

    public List<String> getPistas() {
        return pistas;
    }

    public void setPistas(List<String> pistas) {
        this.pistas = pistas;
    }

    public List<TurnoEjercicio> getTurnos() {
        return turnos;
    }

    public void setTurnos(List<TurnoEjercicio> turnos) {
        this.turnos = turnos;
    }

    public List<String> getDistractores() {
        return distractores;
    }

    public void setDistractores(List<String> distractores) {
        this.distractores = distractores;
    }

    public String getExplicacion() {
        return explicacion;
    }

    public void setExplicacion(String explicacion) {
        this.explicacion = explicacion;
    }
}