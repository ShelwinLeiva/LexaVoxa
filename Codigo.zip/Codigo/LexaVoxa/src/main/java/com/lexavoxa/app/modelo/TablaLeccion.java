package com.lexavoxa.app.modelo;

import java.util.List;

public class TablaLeccion {

    private List<String> columnas;
    private List<List<String>> filas;

    public TablaLeccion() {
    }

    public List<String> getColumnas() {
        return columnas;
    }

    public void setColumnas(List<String> columnas) {
        this.columnas = columnas;
    }

    public List<List<String>> getFilas() {
        return filas;
    }

    public void setFilas(List<List<String>> filas) {
        this.filas = filas;
    }
}