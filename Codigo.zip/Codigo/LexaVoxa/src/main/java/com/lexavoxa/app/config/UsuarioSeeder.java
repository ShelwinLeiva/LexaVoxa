package com.lexavoxa.app.config;

import com.lexavoxa.app.modelo.Usuario;
import com.lexavoxa.app.repositorio.UsuarioRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class UsuarioSeeder implements CommandLineRunner {

    @Autowired
    private UsuarioRepositorio usuarioRepositorio;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (usuarioRepositorio.findByEmail("admin@lexavoxa.com") != null) {
            return;
        }

        Usuario admin = new Usuario();
        admin.setNombre("Admin");
        admin.setEmail("admin@lexavoxa.com");
        admin.setContrasena(passwordEncoder.encode("admin123"));
        admin.setRol("ADMIN");
        admin.setExperiencia(0);
        usuarioRepositorio.save(admin);
    }
}