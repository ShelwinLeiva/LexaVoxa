package com.lexavoxa.app.modelo;

public class LineaDialogo {

    private String hablante;
    private String texto;

    public LineaDialogo() {
    }

    public String getHablante() {
        return hablante;
    }

    public void setHablante(String hablante) {
        this.hablante = hablante;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }
}