package com.lexavoxa.app.modelo;

import java.util.List;

public class PaginaLeccion {

    private String titulo;
    private String introduccion;
    private String objetivo;
    private String recuerda;
    private List<SeccionLeccion> secciones;
    private List<Palabra> vocabulario;
    private List<LineaDialogo> dialogo;

    public PaginaLeccion() {
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getIntroduccion() {
        return introduccion;
    }

    public void setIntroduccion(String introduccion) {
        this.introduccion = introduccion;
    }

    public String getObjetivo() {
        return objetivo;
    }

    public void setObjetivo(String objetivo) {
        this.objetivo = objetivo;
    }

    public String getRecuerda() {
        return recuerda;
    }

    public void setRecuerda(String recuerda) {
        this.recuerda = recuerda;
    }

    public List<SeccionLeccion> getSecciones() {
        return secciones;
    }

    public void setSecciones(List<SeccionLeccion> secciones) {
        this.secciones = secciones;
    }

    public List<Palabra> getVocabulario() {
        return vocabulario;
    }

    public void setVocabulario(List<Palabra> vocabulario) {
        this.vocabulario = vocabulario;
    }

    public List<LineaDialogo> getDialogo() {
        return dialogo;
    }

    public void setDialogo(List<LineaDialogo> dialogo) {
        this.dialogo = dialogo;
    }
}