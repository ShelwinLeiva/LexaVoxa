package com.lexavoxa.app.controlador;

import com.lexavoxa.app.modelo.Pregunta;
import com.lexavoxa.app.servicio.PreguntaServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Arrays;

@Controller
public class PreguntaControlador {

    @Autowired
    private PreguntaServicio preguntaServicio;

    @GetMapping("/preguntas")
    public String listarPreguntas(Model model) {
        model.addAttribute("preguntas", preguntaServicio.listarPreguntas());
        return "preguntas";
    }

    @PostMapping("/preguntas/crear")
    public String crearPregunta(@RequestParam String enunciado,
                                @RequestParam String opciones,
                                @RequestParam String respuestaCorrecta) {
        Pregunta pregunta = new Pregunta();
        pregunta.setEnunciado(enunciado);
        pregunta.setOpciones(Arrays.asList(opciones.split(",")));
        pregunta.setRespuestaCorrecta(respuestaCorrecta);
        preguntaServicio.guardarPregunta(pregunta);
        return "redirect:/preguntas";
    }

    @GetMapping("/preguntas/eliminar/{id}")
    public String eliminarPregunta(@PathVariable String id) {
        preguntaServicio.eliminarPregunta(id);
        return "redirect:/preguntas";
    }
}