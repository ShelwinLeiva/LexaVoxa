package com.lexavoxa.app.servicio;

import com.lexavoxa.app.modelo.Rango;
import com.lexavoxa.app.modelo.Usuario;
import com.lexavoxa.app.repositorio.UsuarioRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

@Service
public class UsuarioServicio {

    @Autowired
    private UsuarioRepositorio usuarioRepositorio;

    @Autowired
    private RangoServicio rangoServicio;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public Usuario registrarUsuario(Usuario usuario) {
        if (usuarioRepositorio.findByEmail(usuario.getEmail()) != null) {
            throw new IllegalArgumentException("Ya existe una cuenta con ese email");
        }
        if (usuarioRepositorio.findByNombreUsuario(usuario.getNombreUsuario()) != null) {
            throw new IllegalArgumentException("Ese nombre de usuario ya está en uso");
        }

        usuario.setContrasena(passwordEncoder.encode(usuario.getContrasena()));
        usuario.setRol("USUARIO");
        usuario.setExperiencia(0);
        usuario.setRachaActual(0);

        Rango rangoBajo = rangoServicio.obtenerRangoMasBajo();
        if (rangoBajo != null) {
            usuario.setRangoId(rangoBajo.getId());
        }

        return usuarioRepositorio.save(usuario);
    }

    public Usuario obtenerUsuarioPorId(String id) {
        if (id == null) {
            return null;
        }
        return usuarioRepositorio.findById(id).orElse(null);
    }

    public Usuario obtenerUsuarioPorEmail(String email) {
        return usuarioRepositorio.findByEmail(email);
    }

    public Usuario seleccionarIdioma(String usuarioId, String idioma) {
        Usuario usuario = usuarioRepositorio.findById(usuarioId)
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));

        usuario.setIdiomas(Arrays.asList(idioma));
        // El curso activo ya no se asigna solo: el usuario lo elige en /cursos-disponibles
        return usuarioRepositorio.save(usuario);
    }

    public Usuario definirMetaDiaria(String usuarioId, int minutos) {
        Usuario usuario = usuarioRepositorio.findById(usuarioId)
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));

        usuario.setMetaDiaria(minutos);
        return usuarioRepositorio.save(usuario);
    }

    public Usuario elegirCursoActivo(String usuarioId, String cursoId) {
        Usuario usuario = usuarioRepositorio.findById(usuarioId)
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));

        usuario.setCursoActivoId(cursoId);
        return usuarioRepositorio.save(usuario);
    }

    public void sumarExperiencia(String usuarioId, int xp) {
        Usuario usuario = usuarioRepositorio.findById(usuarioId).orElse(null);
        if (usuario == null) {
            return;
        }
        usuario.setExperiencia(usuario.getExperiencia() + xp);
        usuarioRepositorio.save(usuario);
    }

    public void actualizarRacha(String usuarioId) {
        Usuario usuario = usuarioRepositorio.findById(usuarioId).orElse(null);
        if (usuario == null) {
            return;
        }

        LocalDate hoy = LocalDate.now();
        LocalDate ultima = usuario.getUltimaActividad();

        if (ultima == null || ultima.isBefore(hoy.minusDays(1))) {
            usuario.setRachaActual(1);
        } else if (ultima.isEqual(hoy.minusDays(1))) {
            usuario.setRachaActual(usuario.getRachaActual() + 1);
        }
        usuario.setUltimaActividad(hoy);
        usuarioRepositorio.save(usuario);
    }

    public int obtenerPosicionEnRanking(String usuarioId) {
        List<Usuario> todos = usuarioRepositorio.findAll();
        todos.sort((a, b) -> Integer.compare(b.getExperiencia(), a.getExperiencia()));

        for (int i = 0; i < todos.size(); i++) {
            if (todos.get(i).getId().equals(usuarioId)) {
                return i + 1;
            }
        }
        return -1;
    }
}